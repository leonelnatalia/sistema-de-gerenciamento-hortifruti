package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Cliente;
import java.util.List;
import javax.persistence.NoResultException;

public class ClienteDAO extends AbstractDAO<Cliente> {

    public List<Cliente> buscarTodos() {
        try {
            return getEntityManager().createNamedQuery("Cliente.buscarTodos", Cliente.class).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public List<Cliente> buscarPorNomeEStatus(String nome, String status) {
        try {
            return getEntityManager().createNamedQuery("Cliente.buscarPorNomeEStatus", Cliente.class).setParameter("nome", "%" + nome + "%").setParameter("status", status).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public Cliente buscarPorCpf(String cpf) {
        try {
            return getEntityManager().createNamedQuery("Cliente.buscarPorCpf", Cliente.class).setParameter("cpf", cpf).getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }

}
