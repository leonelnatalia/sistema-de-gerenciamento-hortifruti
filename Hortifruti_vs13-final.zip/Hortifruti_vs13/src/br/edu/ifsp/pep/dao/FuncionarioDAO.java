package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Funcionario;
import java.util.List;
import javax.persistence.NoResultException;

public class FuncionarioDAO extends AbstractDAO<Funcionario> {

    private static Funcionario funcionarioLogado = null;

    public boolean loginValidacao(String login, String senha) throws Exception {
        boolean logou = false;
        Funcionario funcionarioLogar = buscarPorLogin(login);
        if (funcionarioLogar == null) {
            throw new Exception("Login incorreto!");
        } else if (funcionarioLogar.getSenha().equals(senha)) {
            logou = true;
            logarFuncionario(login, senha);
        } else {
            throw new Exception("Senha incorreta!");
        }
        return logou;
    }

    public Funcionario getFuncionarioLogado() {
        return funcionarioLogado;
    }

    public boolean logarFuncionario(String login, String senha) {
        boolean logou = false;
        Funcionario f = getEntityManager().createNamedQuery("Funcionario.acessar", Funcionario.class).setParameter("login", login).setParameter("senha", senha).getSingleResult();
        if (f != null) {
            funcionarioLogado = f;
            logou = true;
        }
        return logou;
    }

    public void logoutFuncionario() {
        FuncionarioDAO.funcionarioLogado = null;
    }

    public List<Funcionario> buscarTodos() {
        try {
            return getEntityManager().createNamedQuery("Funcionario.buscarTodos", Funcionario.class).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }
    
    public List<Funcionario> buscarPorNomeEStatus(String nome, String status) {
        try {
            return getEntityManager().createNamedQuery("Funcionario.buscarPorNomeEStatus", Funcionario.class).setParameter("nome", "%" + nome + "%").setParameter("status", status).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public Funcionario buscarPorCpf(String cpf) {
        try {
            return getEntityManager().createNamedQuery("Funcionario.buscarPorCpf", Funcionario.class).setParameter("cpf", cpf).getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public Funcionario buscarPorLogin(String login) {
        try {
            return getEntityManager().createNamedQuery("Funcionario.buscarPorLogin", Funcionario.class).setParameter("login", login).getSingleResult();
        } catch (NoResultException ex) { //nenhum resultado
            return null;
        }
    }

    public Funcionario buscarPorCodigo(Integer codigo) {
        try {
            return getEntityManager().createNamedQuery("Funcionario.buscarPorCodigo", Funcionario.class).setParameter("codigo", codigo).getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }
    
}
