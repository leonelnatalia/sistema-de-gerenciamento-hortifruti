package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Produto;
import java.util.List;
import javax.persistence.NoResultException;

public class ProdutoDAO extends AbstractDAO<Produto> {

    public List<Produto> buscarTodos() {
        try {
            return getEntityManager().createNamedQuery("Produto.buscarTodos", Produto.class).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public Produto buscarPorNome(String nome, String status) {
        try {
            return getEntityManager().createNamedQuery("Produto.buscarPorNome", Produto.class).setParameter("nome", nome).setParameter("status", status).getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public List<Produto> buscarPorNomeEStatus(String nome, String status) {
        try {
            return getEntityManager().createNamedQuery("Produto.buscarPorNomeEStatus", Produto.class).setParameter("nome", "%" + nome + "%").setParameter("status", status).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

}
