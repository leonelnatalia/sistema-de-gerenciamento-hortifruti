package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.ItemVenda;
import java.util.List;
import javax.persistence.NoResultException;

public class ItemVendaDAO extends AbstractDAO<ItemVenda> {

    public List<ItemVenda> buscarPorVenda(Long cupom) {
        try {
            return getEntityManager().createNamedQuery("ItemVenda.buscarPorVenda", ItemVenda.class).setParameter("cupom", cupom).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

}
