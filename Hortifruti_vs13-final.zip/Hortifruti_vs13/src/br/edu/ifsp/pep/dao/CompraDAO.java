package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Compra;
import java.util.Date;
import java.util.List;
import javax.persistence.NoResultException;

public class CompraDAO extends AbstractDAO<Compra> {

    public List<Compra> buscarTodas() {
        try {
            return getEntityManager().createNamedQuery("Compra.buscarTodas", Compra.class).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public List<Compra> buscarPorPeriodo(Date data1, Date data2) {
        try {
            return getEntityManager().createNamedQuery("Compra.buscarPorPeriodo", Compra.class).setParameter("data1", data1).setParameter("data2", data2).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

}
