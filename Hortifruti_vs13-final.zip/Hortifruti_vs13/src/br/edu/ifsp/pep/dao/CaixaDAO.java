package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Caixa;
import br.edu.ifsp.pep.modelo.Funcionario;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;
import javax.persistence.NoResultException;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

public class CaixaDAO extends AbstractDAO<Caixa> {

    private static Caixa caixaAberto = null;

    public Caixa getCaixa() {
        return caixaAberto;
    }

    public void setCaixa(Caixa c) {
        caixaAberto = c;
    }

    public Caixa abrirCaixa(BigDecimal saldoAtual) {
        Calendar c = Calendar.getInstance();
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
        Caixa caixa = new Caixa();
        caixa.setDataAbertura(c.getTime());
        caixa.setEntrada(new BigDecimal(0));
        caixa.setSaida(new BigDecimal(0));
        caixa.setSaldo(saldoAtual);
        caixa.setSituacao("A");
        Funcionario f = funcionarioDAO.getFuncionarioLogado();
        caixa.setFuncionario(f);
        try {
            this.inserir(caixa);
            caixaAberto = caixa;
            return caixaAberto;
        } catch (Exception ex) {
            return null;
        }

    }

    public void fecharCaixa() {
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
        Caixa c = buscarAbertoFuncionario(funcionarioDAO.getFuncionarioLogado().getCodigo());
        c.setSituacao("F");
        this.alterar(c);
        caixaAberto = null;
    }

    //chamando função (atualiza caixa venda) criada no pgAdmin
    public void atualizaCaixaVenda(Integer codigoFuncionario, BigDecimal valor) {
        StoredProcedureQuery consulta = getEntityManager().createStoredProcedureQuery("atualiza_caixa_venda");
        consulta.registerStoredProcedureParameter(1, Integer.class, ParameterMode.IN);
        consulta.registerStoredProcedureParameter(2, BigDecimal.class, ParameterMode.IN);
        consulta.setParameter(1, codigoFuncionario);
        consulta.setParameter(2, valor);
        consulta.execute();
    }

    //chamando função (atualiza caixa despesa) criada no pgAdmin
    public void atualizaCaixaDespesa(Integer codigoFuncionario, BigDecimal valor) {
        StoredProcedureQuery consulta = getEntityManager().createStoredProcedureQuery("atualiza_caixa_despesa");
        consulta.registerStoredProcedureParameter(1, Integer.class, ParameterMode.IN);
        consulta.registerStoredProcedureParameter(2, BigDecimal.class, ParameterMode.IN);
        consulta.setParameter(1, codigoFuncionario);
        consulta.setParameter(2, valor);
        consulta.execute();
    }

    public List<Caixa> buscarTodos() {
        try {
            return getEntityManager().createNamedQuery("Caixa.buscarTodos", Caixa.class).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public List<Caixa> buscarAbertos() {
        try {
            return getEntityManager().createNamedQuery("Caixa.buscarAbertos", Caixa.class).setParameter("situacao", "A").getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public Caixa buscarAbertoFuncionario(Integer codigoFuncionario) {
        try {
            return getEntityManager().createNamedQuery("Caixa.buscarPorAbertoFuncionario", Caixa.class).setParameter("situacao", "A").setParameter("codigo", codigoFuncionario).getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }

}
