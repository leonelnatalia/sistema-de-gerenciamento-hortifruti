package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Despesa;
import java.util.Date;
import java.util.List;
import javax.persistence.NoResultException;

public class DespesaDAO extends AbstractDAO<Despesa> {

    public List<Despesa> buscarTodos() {
        try {
            return getEntityManager().createNamedQuery("Despesa.buscarTodos", Despesa.class).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public List<Despesa> buscarPorPeriodo(Date data1, Date data2) {
        try {
            return getEntityManager().createNamedQuery("Despesa.buscarPorPeriodo", Despesa.class).setParameter("data1", data1).setParameter("data2", data2).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public List<Despesa> buscarPorDescricaoEStatus(String descricao, String status) {
        try {
            return getEntityManager().createNamedQuery("Despesa.buscarPorDescricaoEStatus", Despesa.class).setParameter("descricao", "%" + descricao + "%").setParameter("status", status).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }
}
