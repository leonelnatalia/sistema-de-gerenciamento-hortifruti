package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.TipoDespesa;
import java.util.List;
import javax.persistence.NoResultException;

public class TipoDespesaDAO extends AbstractDAO<TipoDespesa> {

    public List<TipoDespesa> buscarTodos() {
        try {
            return getEntityManager().createNamedQuery("TipoDespesa.buscarTodas", TipoDespesa.class).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public List<TipoDespesa> buscarPorDescricaoEStatus(String descricao, String status) {
        try {
            return getEntityManager().createNamedQuery("TipoDespesa.buscarPorDescricaoEStatus", TipoDespesa.class).setParameter("descricao", "%" + descricao + "%").setParameter("status", status).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }
}
