package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.ItemVenda;
import br.edu.ifsp.pep.modelo.Venda;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;

public class VendaDAO extends AbstractDAO<Venda> {

    public List<Venda> buscarTodas() {
        try {
            return getEntityManager().createNamedQuery("Venda.buscarTodas", Venda.class).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public Venda buscarPorCupomFiscal(Long cupom) {
        try {
            return getEntityManager().createNamedQuery("Venda.buscarPorCupomFiscal", Venda.class).setParameter("cupom", cupom).getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public List<Venda> buscarPorPeriodo(Date data1, Date data2) {
        try {
            return getEntityManager().createNamedQuery("Venda.buscarPorPeriodo", Venda.class).setParameter("data1", data1).setParameter("data2", data2).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    @Override
    public void inserir(Venda v) throws Exception {
        EntityManager em = getEntityManager();
        ItemVendaDAO itemVendaDAO = new ItemVendaDAO();
        List<ItemVenda> itens = v.getItemVenda();
        v.setItemVenda(null); //salvar a lista de item venda nula
        em.getTransaction().begin();
        em.persist(v);

        em.getTransaction().commit();
        for (ItemVenda iv : itens) {
            itemVendaDAO.inserir(iv); //inserir itens venda no banco
        }
        v.setItemVenda(itens); //setar a lista de itens venda
        this.alterar(v);
        em.close();
    }
}
