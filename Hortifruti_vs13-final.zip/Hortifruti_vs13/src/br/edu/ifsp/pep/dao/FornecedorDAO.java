package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Fornecedor;
import java.util.List;
import javax.persistence.NoResultException;

public class FornecedorDAO extends AbstractDAO<Fornecedor> {

    public List<Fornecedor> buscarTodos() {
        try {
            return getEntityManager().createNamedQuery("Fornecedor.buscarTodos", Fornecedor.class).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public List<Fornecedor> buscarPorNomeEStatus(String nome, String status) {
        try {
            return getEntityManager().createNamedQuery("Fornecedor.buscarPorNomeEStatus", Fornecedor.class).setParameter("nome", "%" + nome + "%").setParameter("status", status).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public Fornecedor buscarPorCpnj(String cnpj) {
        try {
            return getEntityManager().createNamedQuery("Fornecedor.buscarPorCnpj", Fornecedor.class).setParameter("cnpj", cnpj).getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }

}
