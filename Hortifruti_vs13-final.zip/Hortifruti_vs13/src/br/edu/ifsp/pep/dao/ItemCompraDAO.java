package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.ItemCompra;
import java.util.List;
import javax.persistence.NoResultException;

public class ItemCompraDAO extends AbstractDAO<ItemCompra> {

    public List<ItemCompra> buscarPorCompra(Long codigo) {
        try {
            return getEntityManager().createNamedQuery("ItemCompra.buscarPorCompra", ItemCompra.class).setParameter("codigo", codigo).getResultList();
        } catch (NoResultException ex) {
            return null;
        }
    }

}
