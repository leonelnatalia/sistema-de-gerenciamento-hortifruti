package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "produto")
@NamedQueries(value = {
    @NamedQuery(name = "Produto.buscarTodos", query = "SELECT p FROM Produto p"),
    @NamedQuery(name = "Produto.buscarPorNome", query = "SELECT p FROM Produto p WHERE (UPPER(p.nome) LIKE UPPER(:nome)) AND (p.status LIKE :status)"),
    @NamedQuery(name = "Produto.buscarPorNomeEStatus", query = "SELECT p FROM Produto p WHERE (UPPER(p.nome) LIKE UPPER(:nome)) AND (p.status LIKE :status) ORDER BY p.nome ASC")
})
public class Produto implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo", nullable = false)
    private Long codigo;

    @Column(name = "nome", nullable = false, length = 45)
    private String nome;

    @Column(name = "quantidade", precision = 4, scale = 2, nullable = false)
    private BigDecimal quantidade;

    @Column(name = "valor_compra", precision = 8, scale = 2, nullable = false) //dos 8 números, 2 são usados para casa decimal
    private BigDecimal valorCompra;

    @Column(name = "valor_venda", precision = 8, scale = 2, nullable = false) //dos 8 números, 2 são usados para casa decimal
    private BigDecimal valorVenda;

    @Column(name = "status", length = 1, nullable = false)
    private String status;

    public Produto() {
    }

    public Produto(String nome, BigDecimal quantidade, BigDecimal valorCompra, BigDecimal valorVenda, String status) {
        this.nome = nome;
        this.quantidade = quantidade;
        this.valorCompra = valorCompra;
        this.valorVenda = valorVenda;
        this.status = status;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public BigDecimal getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(BigDecimal quantidade) {
        this.quantidade = quantidade;
    }

    public BigDecimal getValorCompra() {
        return valorCompra;
    }

    public void setValorCompra(BigDecimal valorCompra) {
        this.valorCompra = valorCompra;
    }

    public BigDecimal getValorVenda() {
        return valorVenda;
    }

    public void setValorVenda(BigDecimal valorVenda) {
        this.valorVenda = valorVenda;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
