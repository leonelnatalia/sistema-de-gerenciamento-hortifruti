package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "cliente")
@NamedQueries(value = {
    @NamedQuery(name = "Cliente.buscarTodos", query = "SELECT c FROM Cliente c"),
    @NamedQuery(name = "Cliente.buscarPorCpf", query = "SELECT c FROM Cliente c WHERE c.cpf LIKE :cpf"),
    @NamedQuery(name = "Cliente.buscarPorNomeEStatus", query = "SELECT c FROM Cliente c WHERE (UPPER(c.nome) LIKE UPPER(:nome)) AND (c.status LIKE :status) ORDER BY c.nome ASC")
})
public class Cliente implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //Definir como auto increment
    @Column(name = "codigo", nullable = false)
    private Integer codigo;

    @Column(name = "nome", length = 45, nullable = false)
    private String nome;

    @Column(name = "cpf", length = 14, nullable = false, unique = true)
    private String cpf;

    @Column(name = "email", length = 45, nullable = true)
    private String email;

    @Column(name = "telefone", length = 14, nullable = true)
    private String telefone;

    @Column(name = "status", length = 1, nullable = false)
    private String status;

    public Cliente() {
    }

    public Cliente(String nome, String cpf, String email, String telefone, String status) {
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.telefone = telefone;
        this.status = status;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
