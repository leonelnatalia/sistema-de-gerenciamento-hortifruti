package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "fornecedor")
@NamedQueries(value = {
    @NamedQuery(name = "Fornecedor.buscarTodos", query = "SELECT f FROM Fornecedor f"),
    @NamedQuery(name = "Fornecedor.buscarPorNomeEStatus", query = "SELECT f FROM Fornecedor f WHERE (UPPER(f.nome) LIKE UPPER(:nome)) AND (f.status LIKE :status) ORDER BY f.nome ASC"),
    @NamedQuery(name = "Fornecedor.buscarPorCnpj", query = "SELECT f FROM Fornecedor f WHERE f.cpfCnpj LIKE :Cnpj")
})
public class Fornecedor implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo", nullable = false)
    private Integer codigo;

    @Column(name = "nome", length = 45, nullable = false)
    private String nome;
    
    @Column(name = "telefone", length = 14, nullable = false)
    private String telefone;

    @Column(name = "cpf_cnpj", length = 18, nullable = false, unique = true)
    private String cpfCnpj;

    @Column(name = "status", length = 1, nullable = false)
    private String status;

    public Fornecedor() {
    }

    public Fornecedor(String nome, String telefone, String cpfCnpj, String status) {
        this.nome = nome;
        this.telefone = telefone;
        this.cpfCnpj = cpfCnpj;
        this.status = status;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpfCnpj() {
        return cpfCnpj;
    }

    public void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

}
