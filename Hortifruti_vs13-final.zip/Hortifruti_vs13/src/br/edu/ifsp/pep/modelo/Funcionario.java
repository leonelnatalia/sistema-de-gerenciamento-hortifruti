package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "funcionario")
@NamedQueries(value = {
    @NamedQuery(name = "Funcionario.buscarTodos", query = "SELECT f FROM Funcionario f"),
    @NamedQuery(name = "Funcionario.buscarPorCodigo", query = "SELECT f FROM Funcionario f WHERE f.codigo = :codigo"),
    @NamedQuery(name = "Funcionario.buscarPorCpf", query = "SELECT f FROM Funcionario f WHERE f.cpf LIKE :cpf"),
    @NamedQuery(name = "Funcionario.buscarPorLogin", query = "SELECT f FROM Funcionario f WHERE UPPER(f.login) LIKE UPPER(:login)"),
    @NamedQuery(name = "Funcionario.buscarPorNomeEStatus", query = "SELECT f FROM Funcionario f WHERE (UPPER(f.nome) LIKE UPPER(:nome)) AND (f.status LIKE :status) ORDER BY f.nome ASC"),
    @NamedQuery(name = "Funcionario.acessar", query = "SELECT f FROM Funcionario f WHERE (UPPER(f.login) LIKE UPPER(:login)) AND (f.senha LIKE :senha)")
})
public class Funcionario implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //Definir como auto increment
    @Column(name = "codigo", nullable = false)
    private Integer codigo;
    
    @Column(name = "tipo", length = 1, nullable = false)
    private String tipo;

    @Column(name = "nome", length = 45, nullable = false)
    private String nome;

    @Column(name = "cpf", length = 14, nullable = false, unique = true)
    private String cpf;

    @Column(name = "telefone", length = 14, nullable = false)
    private String telefone;

    @Column(name = "rua", length = 40, nullable = true)
    private String rua;
    
    @Column (name = "numero", nullable = true)
    private Integer numero;
    
    @Column(name = "bairro", length = 40, nullable = true)
    private String bairro;
    
    @Column(name = "cidade", length = 40, nullable = true)
    private String cidade;
    
    @Column(name = "estado", length = 2, nullable = true)
    private String estado;

    @Column(name = "login", length = 20, nullable = false, unique = true)
    private String login;

    @Column(name = "senha", length = 20, nullable = false)
    private String senha;

    @Column(name = "salario", precision = 8, scale = 2, nullable = true) 
    private BigDecimal salario;

    @Column(name = "status", length = 1, nullable = false)
    private String status;

    public Funcionario() {
    }

    public Funcionario(String tipo, String nome, String cpf, String telefone, String rua, Integer numero, String bairro, String cidade, String estado, String login, String senha, BigDecimal salario, String status) {
        this.tipo = tipo;
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
        this.rua = rua;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.login = login;
        this.senha = senha;
        this.salario = salario;
        this.status = status;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}
