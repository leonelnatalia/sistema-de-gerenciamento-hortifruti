package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "caixa")
@NamedQueries(value = {
    @NamedQuery(name = "Caixa.buscarTodos", query = "SELECT c FROM Caixa c"),
    @NamedQuery(name = "Caixa.buscarAbertos", query = "SELECT c FROM Caixa c WHERE c.situacao LIKE :situacao"),
    @NamedQuery(name = "Caixa.buscarPorAbertoFuncionario", query = "SELECT c FROM Caixa c WHERE c.situacao LIKE :situacao AND c.funcionario.codigo = :codigo")
})
public class Caixa implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo", nullable = false)
    private Long codigo;

    @ManyToOne
    @JoinColumn(name = "funcionario_codigo", referencedColumnName = "codigo", nullable = false)
    private Funcionario funcionario;

    @Column(name = "saldo", nullable = false, precision = 8, scale = 2)
    private BigDecimal saldo;

    @Column(name = "entrada", nullable = false, precision = 8, scale = 2)
    private BigDecimal entrada;

    @Column(name = "saida", nullable = false, precision = 8, scale = 2)
    private BigDecimal saida;

    @Column(name = "situacao", nullable = false, length = 1)
    private String situacao; //aberto (A) ou fechado (F)

    @Column(name = "data_abertura", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataAbertura;

    public Caixa() {
    }

    public Caixa(BigDecimal saldo, BigDecimal entrada, BigDecimal saida, String situacao, Date dataAbertura, Funcionario funcionario) {
        this.saldo = saldo;
        this.entrada = entrada;
        this.saida = saida;
        this.situacao = situacao;
        this.dataAbertura = dataAbertura;
        this.funcionario = funcionario;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public BigDecimal getSaldo() {
        return saldo;
    }

    public void setSaldo(BigDecimal saldo) {
        this.saldo = saldo;
    }

    public BigDecimal getEntrada() {
        return entrada;
    }

    public void setEntrada(BigDecimal entrada) {
        this.entrada = entrada;
    }

    public BigDecimal getSaida() {
        return saida;
    }

    public void setSaida(BigDecimal saida) {
        this.saida = saida;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }

    public Date getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(Date dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    @Override
    public String toString() {
        return "Caixa{" + "codigo=" + codigo + ", funcionario=" + funcionario + ", saldo=" + saldo + ", situacao=" + situacao + ", dataAbertura=" + dataAbertura + '}';
    }

}
