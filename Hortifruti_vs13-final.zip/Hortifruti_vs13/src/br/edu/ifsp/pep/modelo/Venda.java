package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "venda")
@NamedQueries(value = {
    @NamedQuery(name = "Venda.buscarTodas", query = "SELECT v FROM Venda v"),
    @NamedQuery(name = "Venda.buscarPorCupomFiscal", query = "SELECT v FROM Venda v WHERE v.cupomFiscal = :cupom"),
    @NamedQuery(name = "Venda.buscarPorPeriodo", query = "SELECT v FROM Venda v WHERE v.dataVenda BETWEEN :data1 AND :data2")
})
public class Venda implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cupom_fiscal", nullable = false)
    private Long cupomFiscal;

    @ManyToOne
    @JoinColumn(name = "caixa_codigo", referencedColumnName = "codigo", nullable = false)
    private Caixa caixa;

    @ManyToOne
    @JoinColumn(name = "cliente_codigo", referencedColumnName = "codigo", nullable = true)
    private Cliente cliente;

    @Column(name = "data_venda", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dataVenda;

    @Column(name = "valor_total", nullable = false, precision = 8, scale = 2)
    private BigDecimal valorTotal;

    @Column(name = "forma_pagamento", nullable = false, length = 17)
    private String formaPagamento;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, mappedBy = "venda")
    private List<ItemVenda> itemVenda;

    public Venda() {
    }

    public Venda(Date dataVenda, BigDecimal valorTotal, String formaPagamento, Caixa caixa) {
        this.dataVenda = dataVenda;
        this.valorTotal = valorTotal;
        this.formaPagamento = formaPagamento;
        this.caixa = caixa;
    }

    public Long getCupomFiscal() {
        return cupomFiscal;
    }

    public void setCupomFiscal(Long cupomFiscal) {
        this.cupomFiscal = cupomFiscal;
    }

    public Date getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(Date dataVenda) {
        this.dataVenda = dataVenda;
    }

    public BigDecimal getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(BigDecimal valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public Caixa getCaixa() {
        return caixa;
    }

    public void setCaixa(Caixa caixa) {
        this.caixa = caixa;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<ItemVenda> getItemVenda() {
        return itemVenda;
    }

    public void setItemVenda(List<ItemVenda> itemVenda) {
        this.itemVenda = itemVenda;
    }

}
