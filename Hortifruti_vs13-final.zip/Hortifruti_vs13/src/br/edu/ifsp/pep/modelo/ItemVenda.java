package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "item_venda")
@IdClass(ItemVendaId.class)
@NamedQueries(value = {
    @NamedQuery(name = "ItemVenda.buscarPorVenda", query = "SELECT iv FROM ItemVenda iv WHERE iv.venda.cupomFiscal = :cupom")
})
public class ItemVenda implements Serializable {

    @Id
    @ManyToOne
    @JoinColumn(name = "produto_codigo", referencedColumnName = "codigo", nullable = false)
    private Produto produto;

    @Id
    @ManyToOne
    @JoinColumn(name = "venda_cupom_fiscal", referencedColumnName = "cupom_fiscal", nullable = false)
    private Venda venda;

    @Column(name = "valor", precision = 8, scale = 2, nullable = false)
    private BigDecimal valor;

    @Column(name = "quantidade", precision = 4, scale = 2, nullable = false)
    private BigDecimal quantidade;

    public ItemVenda() {
    }

    public ItemVenda(Produto produto, Venda venda, BigDecimal valor, BigDecimal quantidade) {
        this.produto = produto;
        this.venda = venda;
        this.valor = valor;
        this.quantidade = quantidade;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Venda getVenda() {
        return venda;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public BigDecimal getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(BigDecimal quantidade) {
        this.quantidade = quantidade;
    }

}
