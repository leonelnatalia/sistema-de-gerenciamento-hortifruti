package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import javax.persistence.Column;

public class ItemCompraId implements Serializable {

    @Column(insertable = false, updatable = false)
    private int produto;
    @Column(insertable = false, updatable = false)
    private int compra;

    public ItemCompraId() {
    }

    public ItemCompraId(int produto, int compra) {
        this.produto = produto;
        this.compra = compra;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + this.produto;
        hash = 97 * hash + this.compra;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ItemCompraId other = (ItemCompraId) obj;
        if (this.produto != other.produto) {
            return false;
        }
        return this.compra == other.compra;
    }
}
