package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "item_compra")
@IdClass(ItemCompraId.class)
@NamedQueries(value = {
    @NamedQuery(name = "ItemCompra.buscarPorCompra", query = "SELECT ic FROM ItemCompra ic WHERE ic.compra.codigo = :codigo")
})
public class ItemCompra implements Serializable {

    @Id
    @ManyToOne
    @JoinColumn(name = "produto_codigo", referencedColumnName = "codigo", nullable = false)
    private Produto produto;

    @Id
    @ManyToOne
    @JoinColumn(name = "compra_codigo", referencedColumnName = "codigo", nullable = false)
    private Compra compra;

    @Column(name = "valor", precision = 8, scale = 2, nullable = false)
    private BigDecimal valor;

    @Column(name = "quantidade", precision = 4, scale = 2, nullable = false)
    private BigDecimal quantidade;

    public ItemCompra() {
    }

    public ItemCompra(Produto produto, Compra compra, BigDecimal valor, BigDecimal quantidade) {
        this.produto = produto;
        this.compra = compra;
        this.valor = valor;
        this.quantidade = quantidade;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Compra getCompra() {
        return compra;
    }

    public void setCompra(Compra compra) {
        this.compra = compra;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public BigDecimal getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(BigDecimal quantidade) {
        this.quantidade = quantidade;
    }

}
