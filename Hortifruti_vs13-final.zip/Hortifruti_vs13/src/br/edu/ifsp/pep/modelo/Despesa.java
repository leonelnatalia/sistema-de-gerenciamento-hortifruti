package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "despesa")
@NamedQueries(value = {
    @NamedQuery(name = "Despesa.buscarTodos", query = "SELECT d FROM Despesa d"),
    @NamedQuery(name = "Despesa.buscarPorPeriodo", query = "SELECT d FROM Despesa d WHERE d.dataLancamento BETWEEN :data1 AND :data2"),
    @NamedQuery(name = "Despesa.buscarPorDescricaoEStatus", query = "SELECT d FROM Despesa d WHERE (UPPER(d.tipoDespesa.descricao) LIKE UPPER(:descricao)) AND (d.status LIKE :status)")
})
public class Despesa implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo", nullable = false)
    private Long codigo;

    @ManyToOne
    @JoinColumn(name = "caixa_codigo", referencedColumnName = "codigo", nullable = false)
    private Caixa caixa;

    @ManyToOne
    @JoinColumn(name = "tipo_despesa_codigo", referencedColumnName = "codigo", nullable = false)
    private TipoDespesa tipoDespesa;

    @Column(name = "valor", precision = 8, scale = 2, nullable = false)
    private BigDecimal valor;

    @Column(name = "data_lancamento", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dataLancamento;

    @Column(name = "forma_pagamento", nullable = false, length = 17)
    private String formaPagamento;

    @Column(name = "status", length = 1, nullable = false)
    private String status;

    public Despesa() {
    }

    public Despesa(Caixa caixa, TipoDespesa tipoDespesa, BigDecimal valor, Date dataLancamento, String formaPagamento, String status) {
        this.caixa = caixa;
        this.tipoDespesa = tipoDespesa;
        this.valor = valor;
        this.dataLancamento = dataLancamento;
        this.formaPagamento = formaPagamento;
        this.status = status;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Date getDataLancamento() {
        return dataLancamento;
    }

    public void setDataLancamento(Date dataLancamento) {
        this.dataLancamento = dataLancamento;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public TipoDespesa getTipoDespesa() {
        return tipoDespesa;
    }

    public void setTipoDespesa(TipoDespesa tipoDespesa) {
        this.tipoDespesa = tipoDespesa;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Caixa getCaixa() {
        return caixa;
    }

    public void setCaixa(Caixa caixa) {
        this.caixa = caixa;
    }

}
