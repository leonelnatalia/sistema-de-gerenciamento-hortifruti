package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;

public class ItemVendaId implements Serializable {

    @Column(insertable = false, updatable = false)
    private Long produto;
    @Column(insertable = false, updatable = false)
    private Long venda;

    public ItemVendaId() {
    }

    public ItemVendaId(Long produto, Long venda) {
        this.produto = produto;
        this.venda = venda;
    }

    public Long getProduto() {
        return produto;
    }

    public void setProduto(Long produto) {
        this.produto = produto;
    }

    public Long getVenda() {
        return venda;
    }

    public void setVenda(Long venda) {
        this.venda = venda;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 13 * hash + Objects.hashCode(this.produto);
        hash = 13 * hash + Objects.hashCode(this.venda);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ItemVendaId other = (ItemVendaId) obj;
        if (!Objects.equals(this.produto, other.produto)) {
            return false;
        }
        return Objects.equals(this.venda, other.venda);
    }

}
