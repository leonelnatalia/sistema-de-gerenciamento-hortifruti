package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;

@Entity
@Table(name = "compra")
@NamedQueries(value = {
    @NamedQuery(name = "Compra.buscarTodas", query = "SELECT c FROM Compra c"),
    @NamedQuery(name = "Compra.buscarPorPeriodo", query = "SELECT c FROM Compra c WHERE c.dataCompra BETWEEN :data1 AND :data2")
})
public class Compra implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo", nullable = false)
    private Long codigo;

    @ManyToOne
    @JoinColumn(name = "fornecedor_codigo", referencedColumnName = "codigo", nullable = false)
    private Fornecedor fornecedor;

    @ManyToOne
    @JoinColumn(name = "caixa_codigo", referencedColumnName = "codigo", nullable = false)
    private Caixa caixa;

    @Column(name = "data_compra", nullable = false)
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date dataCompra;

    @Column(name = "valor_total", nullable = false, precision = 8, scale = 2)
    private BigDecimal valorTotal;

    @Column(name = "forma_pagamento", nullable = false, length = 17)
    private String formaPagamento;

    public Compra() {
    }

    public Compra(Fornecedor fornecedor, Date dataCompra, BigDecimal valorTotal, String formaPagamento, Caixa caixa) {
        this.fornecedor = fornecedor;
        this.dataCompra = dataCompra;
        this.valorTotal = valorTotal;
        this.formaPagamento = formaPagamento;
        this.caixa = caixa;
    }

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    public Date getDataCompra() {
        return dataCompra;
    }

    public void setDataCompra(Date dataCompra) {
        this.dataCompra = dataCompra;
    }

    public BigDecimal getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(BigDecimal valorTotal) {
        this.valorTotal = valorTotal;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public Caixa getCaixa() {
        return caixa;
    }

    public void setCaixa(Caixa caixa) {
        this.caixa = caixa;
    }

}
