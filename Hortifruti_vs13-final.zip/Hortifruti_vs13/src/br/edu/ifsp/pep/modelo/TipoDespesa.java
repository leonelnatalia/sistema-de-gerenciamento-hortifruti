package br.edu.ifsp.pep.modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "tipo_despesa")
@NamedQueries(value = {
    @NamedQuery(name = "TipoDespesa.buscarTodas", query = "SELECT td FROM TipoDespesa td"),
    @NamedQuery(name = "TipoDespesa.buscarPorDescricaoEStatus", query = "SELECT td FROM TipoDespesa td WHERE (UPPER(td.descricao) LIKE UPPER(:descricao)) AND (td.status LIKE :status) ORDER BY td.descricao")
})
public class TipoDespesa implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo", nullable = false)
    private Integer codigo;

    @Column(name = "descricao", nullable = false, length = 45)
    private String descricao;

    @Column(name = "status", length = 1, nullable = false)
    private String status;

    public TipoDespesa() {
    }

    public TipoDespesa(String descricao, String status) {
        this.descricao = descricao;
        this.status = status;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
