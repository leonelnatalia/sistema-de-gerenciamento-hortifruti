package br.edu.ifsp.pep.visao;

import br.edu.ifsp.pep.dao.CaixaDAO;
import br.edu.ifsp.pep.dao.FuncionarioDAO;
import br.edu.ifsp.pep.modelo.Caixa;
import br.edu.ifsp.pep.modelo.Funcionario;
import java.awt.Color;
import util.Utilidade;

public class PrincipalView extends javax.swing.JFrame {

    private FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
    private CaixaDAO caixaDAO = new CaixaDAO();
    private Utilidade util = new Utilidade(); //usado para enviar mensagens e formatar datas
    private Funcionario funcionario = new Funcionario();

    public PrincipalView() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setExtendedState(PrincipalView.MAXIMIZED_BOTH);
        this.funcionario = funcionarioDAO.getFuncionarioLogado();
        if (caixaDAO.buscarAbertoFuncionario(funcionario.getCodigo()) != null) { //se tem caixa aberto
            caixaDAO.setCaixa(caixaDAO.buscarAbertoFuncionario(funcionario.getCodigo()));
            atualizaSaldo();
            abrirCaixaTexto();
        } else { //se o caixa está fechado
            fecharCaixaTexto();
        }
        lFuncionario.setText(funcionario.getNome());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        pBotoes = new javax.swing.JPanel();
        bDespesas = new javax.swing.JButton();
        bAdicionarVenda = new javax.swing.JButton();
        bClientes = new javax.swing.JButton();
        bRelatorios = new javax.swing.JButton();
        bProdutos = new javax.swing.JButton();
        bFuncionarios = new javax.swing.JButton();
        bEstoque = new javax.swing.JButton();
        bFornecedores = new javax.swing.JButton();
        pCabecalho = new javax.swing.JPanel();
        pCaixa = new javax.swing.JPanel();
        lSaldo = new javax.swing.JLabel();
        bCaixa = new javax.swing.JButton();
        lCaixa = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        pRodape = new javax.swing.JPanel();
        lFuncionario = new javax.swing.JLabel();
        bDesconectar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        pBotoes.setBackground(new java.awt.Color(217, 217, 217));

        bDespesas.setBackground(new java.awt.Color(69, 95, 68));
        bDespesas.setFont(new java.awt.Font("Noto Sans CJK SC", 0, 24)); // NOI18N
        bDespesas.setForeground(new java.awt.Color(255, 255, 255));
        bDespesas.setText("Despesas");
        bDespesas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bDespesasActionPerformed(evt);
            }
        });

        bAdicionarVenda.setBackground(new java.awt.Color(69, 95, 68));
        bAdicionarVenda.setFont(new java.awt.Font("Noto Sans CJK SC", 0, 24)); // NOI18N
        bAdicionarVenda.setForeground(new java.awt.Color(255, 255, 255));
        bAdicionarVenda.setText("Adicionar venda");
        bAdicionarVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAdicionarVendaActionPerformed(evt);
            }
        });

        bClientes.setBackground(new java.awt.Color(69, 95, 68));
        bClientes.setFont(new java.awt.Font("Noto Sans CJK SC", 0, 24)); // NOI18N
        bClientes.setForeground(new java.awt.Color(255, 255, 255));
        bClientes.setText("Clientes");
        bClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bClientesActionPerformed(evt);
            }
        });

        bRelatorios.setBackground(new java.awt.Color(69, 95, 68));
        bRelatorios.setFont(new java.awt.Font("Noto Sans CJK SC", 0, 24)); // NOI18N
        bRelatorios.setForeground(new java.awt.Color(255, 255, 255));
        bRelatorios.setText("Relatórios");
        bRelatorios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bRelatoriosActionPerformed(evt);
            }
        });

        bProdutos.setBackground(new java.awt.Color(69, 95, 68));
        bProdutos.setFont(new java.awt.Font("Noto Sans CJK SC", 0, 24)); // NOI18N
        bProdutos.setForeground(new java.awt.Color(255, 255, 255));
        bProdutos.setText("Produtos");
        bProdutos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bProdutosActionPerformed(evt);
            }
        });

        bFuncionarios.setBackground(new java.awt.Color(69, 95, 68));
        bFuncionarios.setFont(new java.awt.Font("Noto Sans CJK SC", 0, 24)); // NOI18N
        bFuncionarios.setForeground(new java.awt.Color(255, 255, 255));
        bFuncionarios.setText("Funcionários");
        bFuncionarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bFuncionariosActionPerformed(evt);
            }
        });

        bEstoque.setBackground(new java.awt.Color(69, 95, 68));
        bEstoque.setFont(new java.awt.Font("Noto Sans CJK SC", 0, 24)); // NOI18N
        bEstoque.setForeground(new java.awt.Color(255, 255, 255));
        bEstoque.setText("Estoque");
        bEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEstoqueActionPerformed(evt);
            }
        });

        bFornecedores.setBackground(new java.awt.Color(69, 95, 68));
        bFornecedores.setFont(new java.awt.Font("Noto Sans CJK SC", 0, 24)); // NOI18N
        bFornecedores.setForeground(new java.awt.Color(255, 255, 255));
        bFornecedores.setText("Fornecedores");
        bFornecedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bFornecedoresActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pBotoesLayout = new javax.swing.GroupLayout(pBotoes);
        pBotoes.setLayout(pBotoesLayout);
        pBotoesLayout.setHorizontalGroup(
            pBotoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pBotoesLayout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(pBotoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bRelatorios, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bAdicionarVenda, javax.swing.GroupLayout.DEFAULT_SIZE, 273, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 112, Short.MAX_VALUE)
                .addGroup(pBotoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bDespesas, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bProdutos, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(86, 86, 86)
                .addGroup(pBotoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pBotoesLayout.createSequentialGroup()
                        .addComponent(bFuncionarios, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(138, 138, 138)
                        .addComponent(bClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pBotoesLayout.createSequentialGroup()
                        .addComponent(bEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(138, 138, 138)
                        .addComponent(bFornecedores, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50))
        );
        pBotoesLayout.setVerticalGroup(
            pBotoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pBotoesLayout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(pBotoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bAdicionarVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bDespesas, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bFuncionarios, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                .addGroup(pBotoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bFornecedores, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bProdutos, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bRelatorios, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(70, 70, 70))
        );

        pCabecalho.setBackground(new java.awt.Color(69, 95, 68));

        pCaixa.setBackground(new java.awt.Color(154, 198, 109));

        lSaldo.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lSaldo.setForeground(new java.awt.Color(69, 95, 68));
        lSaldo.setText("Saldo: R$0,00");

        bCaixa.setBackground(new java.awt.Color(69, 95, 68));
        bCaixa.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        bCaixa.setForeground(new java.awt.Color(255, 255, 255));
        bCaixa.setText("ABRIR");
        bCaixa.setBorder(null);
        bCaixa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCaixaActionPerformed(evt);
            }
        });

        lCaixa.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        lCaixa.setForeground(new java.awt.Color(255, 255, 255));
        lCaixa.setText("CAIXA FECHADO");

        javax.swing.GroupLayout pCaixaLayout = new javax.swing.GroupLayout(pCaixa);
        pCaixa.setLayout(pCaixaLayout);
        pCaixaLayout.setHorizontalGroup(
            pCaixaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCaixaLayout.createSequentialGroup()
                .addGap(199, 199, 199)
                .addGroup(pCaixaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lCaixa)
                    .addComponent(lSaldo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bCaixa, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        pCaixaLayout.setVerticalGroup(
            pCaixaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCaixaLayout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(pCaixaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pCaixaLayout.createSequentialGroup()
                        .addComponent(bCaixa, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8))
                    .addGroup(pCaixaLayout.createSequentialGroup()
                        .addComponent(lCaixa)
                        .addGap(3, 3, 3)
                        .addComponent(lSaldo, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Corbel Light", 0, 52)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(184, 236, 135));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/logo.png"))); // NOI18N

        javax.swing.GroupLayout pCabecalhoLayout = new javax.swing.GroupLayout(pCabecalho);
        pCabecalho.setLayout(pCabecalhoLayout);
        pCabecalhoLayout.setHorizontalGroup(
            pCabecalhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCabecalhoLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pCaixa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );
        pCabecalhoLayout.setVerticalGroup(
            pCabecalhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pCabecalhoLayout.createSequentialGroup()
                .addComponent(pCaixa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pCabecalhoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pRodape.setBackground(new java.awt.Color(154, 198, 109));

        lFuncionario.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lFuncionario.setForeground(new java.awt.Color(69, 95, 68));
        lFuncionario.setText("Gerente ");

        bDesconectar.setBackground(new java.awt.Color(102, 102, 102));
        bDesconectar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bDesconectar.setForeground(new java.awt.Color(255, 255, 255));
        bDesconectar.setText("Desconectar");
        bDesconectar.setBorder(null);
        bDesconectar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bDesconectarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pRodapeLayout = new javax.swing.GroupLayout(pRodape);
        pRodape.setLayout(pRodapeLayout);
        pRodapeLayout.setHorizontalGroup(
            pRodapeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pRodapeLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lFuncionario)
                .addGap(18, 18, 18)
                .addComponent(bDesconectar, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );
        pRodapeLayout.setVerticalGroup(
            pRodapeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pRodapeLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(pRodapeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bDesconectar, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                    .addComponent(lFuncionario))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pRodape, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pCabecalho, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(pBotoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 6, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(pCabecalho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pBotoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(pRodape, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bDespesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bDespesasActionPerformed
        if (funcionario.getTipo().equals("G")) { //gerente está logado
            if (caixaDAO.getCaixa() == null) {
                util.exibirMensagem("Antes de cadastrar despesas, abra um caixa!");
            } else {
                DespesaView tela = new DespesaView(this, true);
                tela.setVisible(true);
                atualizaSaldo();
            }
        } else {
            util.exibirMensagemWarning("Você não tem acesso a essa funcionalidade.");
        }
    }//GEN-LAST:event_bDespesasActionPerformed

    private void bFornecedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bFornecedoresActionPerformed
        if (funcionario.getTipo().equals("G")) { //gerente está logado
            util.exibirMensagemWarning("Função indisponível");
        } else {
            util.exibirMensagemWarning("Você não tem acesso a essa funcionalidade.");
        }
    }//GEN-LAST:event_bFornecedoresActionPerformed

    private void bAdicionarVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAdicionarVendaActionPerformed
        if (caixaDAO.getCaixa() == null) {
            util.exibirMensagem("Antes de realizar uma venda, abra um caixa!");
        } else {
            VendaView tela = new VendaView(this, true);
            tela.setVisible(true);
            atualizaSaldo();
        }
    }//GEN-LAST:event_bAdicionarVendaActionPerformed

    private void bClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bClientesActionPerformed
        if (funcionario.getTipo().equals("G")) { //gerente está logado
            util.exibirMensagemWarning("Função indisponível");
        } else {
            util.exibirMensagemWarning("Você não tem acesso a essa funcionalidade.");
        }
    }//GEN-LAST:event_bClientesActionPerformed

    private void bRelatoriosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bRelatoriosActionPerformed
        if (funcionario.getTipo().equals("G")) { //gerente está logado
            RelatorioView tela = new RelatorioView();
            tela.setVisible(true);
        } else {
            util.exibirMensagemWarning("Você não tem acesso a essa funcionalidade.");
        }
    }//GEN-LAST:event_bRelatoriosActionPerformed

    private void bProdutosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bProdutosActionPerformed
        if (funcionario.getTipo().equals("G")) { //gerente está logado
            ProdutoView tela = new ProdutoView(this, true);
            tela.setVisible(true);
        } else {
            util.exibirMensagemWarning("Você não tem acesso a essa funcionalidade.");
        }
    }//GEN-LAST:event_bProdutosActionPerformed

    private void bFuncionariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bFuncionariosActionPerformed
        if (funcionario.getTipo().equals("G")) { //gerente está logado
            FuncionarioView tela = new FuncionarioView(this, true);
            tela.setVisible(true);
        } else {
            util.exibirMensagemWarning("Você não tem acesso a essa funcionalidade.");
        }
    }//GEN-LAST:event_bFuncionariosActionPerformed

    private void bEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEstoqueActionPerformed
        if (funcionario.getTipo().equals("G")) { //gerente está logado
            GerenciarEstoqueView tela = new GerenciarEstoqueView(this, true);
            tela.setVisible(true);
        } else {
            util.exibirMensagemWarning("Você não tem acesso a essa funcionalidade.");
        }
    }//GEN-LAST:event_bEstoqueActionPerformed

    private void bCaixaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCaixaActionPerformed
        if (bCaixa.getText().equals("Fechar")) { //se quer fechar o caixa
            if (caixaDAO.buscarAbertoFuncionario(funcionario.getCodigo()) == null) {
                //não há caixa aberto
                util.exibirMensagemWarning("Não há caixa aberto!");
                fecharCaixaTexto();
            } else {
                caixaDAO.fecharCaixa();
                fecharCaixaTexto();
            }
        } else { //se quer abrir o caixa
            if (caixaDAO.buscarAbertoFuncionario(funcionario.getCodigo()) != null) { //o funcionário já tem caixa aberto
                util.exibirMensagemWarning("Você já possui um caixa aberto.");
                this.abrirCaixaTexto();
            } else {
                InserirSaldoView tela = new InserirSaldoView(null, true); //apresentar tela para inserir o saldo
                tela.setVisible(true);
                if (tela.isSalvou()) {
                    try {
                        caixaDAO.abrirCaixa(tela.getSaldo());
                    } catch (Exception ex) {
                        util.exibirMensagemWarning("Erro ao abrir caixa.");
                    }
                    atualizaSaldo();
                    abrirCaixaTexto();
                }
            }
        }
    }//GEN-LAST:event_bCaixaActionPerformed

    private void bDesconectarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bDesconectarActionPerformed
        if (util.exibirMensagemConfirmacaoLogout() == 0) { //deseja desconectar
            funcionarioDAO.logoutFuncionario();
            LoginView tela = new LoginView();
            tela.setVisible(true);
            dispose();
        }
    }//GEN-LAST:event_bDesconectarActionPerformed

    private void fecharCaixaTexto() { //alterar os textos para "caixa fechado"
        lCaixa.setText("CAIXA FECHADO");
        bCaixa.setText("Abrir");
        bCaixa.setBackground(new Color(69, 95, 68));
        lSaldo.setText("Saldo: R$0,00");
    }

    private void abrirCaixaTexto() { //alterar os textos para "caixa aberto"
        lCaixa.setText("CAIXA ABERTO");
        bCaixa.setText("Fechar");
        bCaixa.setBackground(new Color(102, 0, 0));
    }

    private void atualizaSaldo() {
        Caixa aberto = caixaDAO.buscarAbertoFuncionario(funcionario.getCodigo());
        lSaldo.setText("Saldo: R$" + String.valueOf(aberto.getSaldo()));
    }

//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Principal().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAdicionarVenda;
    private javax.swing.JButton bCaixa;
    private javax.swing.JButton bClientes;
    private javax.swing.JButton bDesconectar;
    private javax.swing.JButton bDespesas;
    private javax.swing.JButton bEstoque;
    private javax.swing.JButton bFornecedores;
    private javax.swing.JButton bFuncionarios;
    private javax.swing.JButton bProdutos;
    private javax.swing.JButton bRelatorios;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lCaixa;
    private javax.swing.JLabel lFuncionario;
    private javax.swing.JLabel lSaldo;
    private javax.swing.JPanel pBotoes;
    private javax.swing.JPanel pCabecalho;
    private javax.swing.JPanel pCaixa;
    private javax.swing.JPanel pRodape;
    // End of variables declaration//GEN-END:variables
}
