package br.edu.ifsp.pep.visao;

import br.edu.ifsp.pep.dao.FuncionarioDAO;
import br.edu.ifsp.pep.dao.ProdutoDAO;
import br.edu.ifsp.pep.modelo.Produto;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import util.Utilidade;

public class ProdutoView extends javax.swing.JDialog {

    private ProdutoDAO produtoDAO = new ProdutoDAO();
    private FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
    private List<Produto> produtos = new ArrayList<>();
    private Utilidade util = new Utilidade(); //serve para enviar mensagens e formatar datas
    //variáveis utilizadas na classe atual
    private boolean alterar = false; //variável para saber se está alterando ou adicionando
    private Long codigo; //código do produto que irá alterar

    public ProdutoView(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.setLocationRelativeTo(null);
        lFuncionario.setText(funcionarioDAO.getFuncionarioLogado().getNome());
        atualizarTabela();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        pRodae = new javax.swing.JPanel();
        lFuncionario = new javax.swing.JLabel();
        bTelaInicial = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tProdutos = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        bPesquisar = new javax.swing.JButton();
        labNome = new javax.swing.JLabel();
        labQuantidade = new javax.swing.JLabel();
        labValorVenda = new javax.swing.JLabel();
        labValorCompra = new javax.swing.JLabel();
        tfNome = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        bExcluir = new javax.swing.JButton();
        bCancelar = new javax.swing.JButton();
        bAlterar = new javax.swing.JButton();
        bSalvar = new javax.swing.JButton();
        tfPesquisar = new javax.swing.JTextField();
        tfValorVenda = new javax.swing.JTextField();
        tfValorCompra = new javax.swing.JTextField();
        tfQuantidade = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        pRodae.setBackground(new java.awt.Color(154, 198, 109));
        pRodae.setPreferredSize(new java.awt.Dimension(1316, 60));

        lFuncionario.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lFuncionario.setForeground(new java.awt.Color(69, 95, 68));
        lFuncionario.setText("Gerente ");

        bTelaInicial.setBackground(new java.awt.Color(102, 102, 102));
        bTelaInicial.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bTelaInicial.setForeground(new java.awt.Color(255, 255, 255));
        bTelaInicial.setText("Tela inicial");
        bTelaInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTelaInicialActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pRodaeLayout = new javax.swing.GroupLayout(pRodae);
        pRodae.setLayout(pRodaeLayout);
        pRodaeLayout.setHorizontalGroup(
            pRodaeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pRodaeLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(bTelaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );
        pRodaeLayout.setVerticalGroup(
            pRodaeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pRodaeLayout.createSequentialGroup()
                .addContainerGap(7, Short.MAX_VALUE)
                .addGroup(pRodaeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bTelaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lFuncionario))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(217, 217, 217));

        tProdutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Quantidade", "Valor Compra", "Valor Venda"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tProdutos);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(69, 95, 68));
        jLabel4.setText("PRODUTOS");

        bPesquisar.setBackground(new java.awt.Color(69, 95, 68));
        bPesquisar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bPesquisar.setForeground(new java.awt.Color(255, 255, 255));
        bPesquisar.setText("Pesquisar");
        bPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPesquisarActionPerformed(evt);
            }
        });

        labNome.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labNome.setText("Nome:");

        labQuantidade.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labQuantidade.setText("Quantidade:");

        labValorVenda.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labValorVenda.setText("Valor de venda:");

        labValorCompra.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labValorCompra.setText("Valor de compra:");

        tfNome.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        jPanel4.setLayout(new java.awt.GridLayout(1, 0, 0, 25));

        bExcluir.setBackground(new java.awt.Color(102, 0, 0));
        bExcluir.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bExcluir.setForeground(new java.awt.Color(255, 255, 255));
        bExcluir.setText("Excluir");
        bExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bExcluirActionPerformed(evt);
            }
        });
        jPanel4.add(bExcluir);

        bCancelar.setBackground(new java.awt.Color(102, 102, 102));
        bCancelar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bCancelar.setForeground(new java.awt.Color(255, 255, 255));
        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });
        jPanel4.add(bCancelar);

        bAlterar.setBackground(new java.awt.Color(102, 102, 102));
        bAlterar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bAlterar.setForeground(new java.awt.Color(255, 255, 255));
        bAlterar.setText("Alterar");
        bAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAlterarActionPerformed(evt);
            }
        });
        jPanel4.add(bAlterar);

        bSalvar.setBackground(new java.awt.Color(69, 95, 68));
        bSalvar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bSalvar.setForeground(new java.awt.Color(255, 255, 255));
        bSalvar.setText("Salvar");
        bSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSalvarActionPerformed(evt);
            }
        });
        jPanel4.add(bSalvar);

        tfPesquisar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        tfValorVenda.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        tfValorCompra.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        tfQuantidade.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(tfPesquisar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(71, 71, 71)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(labNome)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfNome, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(labQuantidade)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(labValorVenda)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tfValorVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(labValorCompra)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfValorCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(552, 552, 552)
                        .addComponent(jLabel4))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1304, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labNome)
                            .addComponent(labQuantidade)
                            .addComponent(tfNome, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(52, 52, 52)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labValorVenda)
                            .addComponent(labValorCompra)
                            .addComponent(tfValorVenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfValorCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        jPanel3.setBackground(new java.awt.Color(69, 95, 68));

        jLabel1.setFont(new java.awt.Font("Corbel Light", 0, 52)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(184, 236, 135));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/logo.png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pRodae, javax.swing.GroupLayout.DEFAULT_SIZE, 1335, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pRodae, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1330, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1330, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 706, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bTelaInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTelaInicialActionPerformed
        dispose();
    }//GEN-LAST:event_bTelaInicialActionPerformed

    private void bPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPesquisarActionPerformed
        atualizarTabela();
    }//GEN-LAST:event_bPesquisarActionPerformed

    private void bExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bExcluirActionPerformed
        int linha = tProdutos.getSelectedRow();
        if (linha == -1) {
            util.exibirMensagemWarning("Selecione uma linha na tabela");
        } else {
            if (util.exibirMensagemConfirmacaoExcluir() == 0) {
                Produto produtoRemover = produtos.get(linha);
                produtoRemover.setStatus("I");
                produtoDAO.alterar(produtoRemover);
                util.exibirMensagem("Produto excluído");
                atualizarTabela();
                limparCampos();
            }
        }
    }//GEN-LAST:event_bExcluirActionPerformed

    private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
        if ((!tfNome.getText().isEmpty()) || (!tfValorCompra.getText().isEmpty())
                || (!tfValorVenda.getText().isEmpty())) { //campos estão preenchidos
            if (util.exibirMensagemConfirmacaoCancelar() == 0) { //deseja cancelar?
                limparCampos();
            }
        } else {
            limparCampos();
        }
    }//GEN-LAST:event_bCancelarActionPerformed

    private void bAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAlterarActionPerformed
        int linha = tProdutos.getSelectedRow();
        if (linha == -1) {
            util.exibirMensagemWarning("Selecione uma linha na tabela");
        } else {
            Produto produtoAlterar = produtos.get(linha);
            tfValorVenda.setText(String.valueOf(produtoAlterar.getValorVenda()));
            tfNome.setText(produtoAlterar.getNome());
            tfValorCompra.setText(String.valueOf(produtoAlterar.getValorCompra()));
            tfQuantidade.setText(String.valueOf(produtoAlterar.getQuantidade()));
            alterar = true;
            tfQuantidade.setEnabled(false); //não pode alterar a quantidade, só altera na compra (aumentar) ou no gerenciar estoque (diminuir)
            this.codigo = produtoAlterar.getCodigo();
        }
    }//GEN-LAST:event_bAlterarActionPerformed

    private void bSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSalvarActionPerformed
        if (tfNome.getText().isEmpty()) { //nome é o único campo obrigatório
            util.exibirMensagemWarning("Preencha o nome, por favor!");
            tfNome.requestFocus();
        } else {
            Produto p = new Produto();
            p.setStatus("A");
            p.setNome(tfNome.getText());

            if (tfQuantidade.getText().isEmpty()) { //se o campo de quantidade está vazio
                p.setQuantidade(new BigDecimal(0)); //setar quantidade = 0
            } else {
                String quantidade = tfQuantidade.getText();
                if (tfQuantidade.getText().contains(",")) {
                    quantidade = tfQuantidade.getText().replace(",", "."); //substituir , por . (evita erros)
                }
                p.setQuantidade(new BigDecimal(quantidade));
            }

            if (tfValorVenda.getText().isEmpty()) { //se o campo está vazio
                p.setValorVenda(new BigDecimal(0)); //setar valor venda = 0
            } else {
                String valorVenda = tfValorVenda.getText();
                if (tfValorVenda.getText().contains(",")) {
                    valorVenda = tfValorVenda.getText().replace(",", ".");//substituir , por . (evita erros)
                }
                p.setValorVenda(new BigDecimal(valorVenda));
            }

            if (tfValorCompra.getText().isEmpty()) { //se o campo está vazio
                p.setValorCompra(new BigDecimal(0)); //setar valor compra = 0
            } else {
                String valorCompra = tfValorCompra.getText();
                if (tfValorCompra.getText().contains(",")) {
                    valorCompra = tfValorCompra.getText().replace(",", ".");//substituir , por . (evita erros)
                }
                p.setValorCompra(new BigDecimal(valorCompra));
            }

            if (alterar == false) { //adicionar produto
                Produto validar = produtoDAO.buscarPorNome(tfNome.getText(), "A"); //validar se existe um
                //produto com esse mesmo nome
                if (validar == null) { //não existe nenhum produto cadastrado com esse nome
                    try {
                        produtoDAO.inserir(p);
                        util.exibirMensagem("Produto adicionado!");
                        atualizarTabela();
                        limparCampos();
                    } catch (Exception ex) {
                        util.exibirMensagemError("Erro ao adicionar.");
                    }
                } else {
                    util.exibirMensagemWarning("Já existe um produto cadastrado com esse nome!");
                }
            } else { //alterar produto
                p.setCodigo(codigo);
                produtoDAO.alterar(p);
                util.exibirMensagem("Produto alterado!");
                alterar = false;
                atualizarTabela();
                limparCampos();
                tfQuantidade.setEnabled(true);
            }
        }
    }//GEN-LAST:event_bSalvarActionPerformed

    private void atualizarTabela() {
        DefaultTableModel modelo = (DefaultTableModel) tProdutos.getModel();
        modelo.setNumRows(0);
        produtos.clear();
        produtos.addAll(produtoDAO.buscarPorNomeEStatus(tfPesquisar.getText(), "A"));

        for (Produto p : produtos) {
            modelo.addRow(new Object[]{p.getNome(), p.getQuantidade(), p.getValorCompra(), p.getValorVenda()});
        }

    }

    private void limparCampos() {
        tfValorVenda.setText("");
        tfValorCompra.setText("");
        tfNome.setText("");
        tfQuantidade.setText("");
    }

//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(ProdutoView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(ProdutoView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(ProdutoView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(ProdutoView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the dialog */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                ProdutoView1 dialog = new ProdutoView1(new javax.swing.JFrame(), true);
//                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
//                    @Override
//                    public void windowClosing(java.awt.event.WindowEvent e) {
//                        System.exit(0);
//                    }
//                });
//                dialog.setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAlterar;
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bExcluir;
    private javax.swing.JButton bPesquisar;
    private javax.swing.JButton bSalvar;
    private javax.swing.JButton bTelaInicial;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lFuncionario;
    private javax.swing.JLabel labNome;
    private javax.swing.JLabel labQuantidade;
    private javax.swing.JLabel labValorCompra;
    private javax.swing.JLabel labValorVenda;
    private javax.swing.JPanel pRodae;
    private javax.swing.JTable tProdutos;
    private javax.swing.JTextField tfNome;
    private javax.swing.JTextField tfPesquisar;
    private javax.swing.JTextField tfQuantidade;
    private javax.swing.JTextField tfValorCompra;
    private javax.swing.JTextField tfValorVenda;
    // End of variables declaration//GEN-END:variables
}
