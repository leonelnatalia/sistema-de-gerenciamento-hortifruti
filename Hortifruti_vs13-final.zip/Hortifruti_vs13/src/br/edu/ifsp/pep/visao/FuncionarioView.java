package br.edu.ifsp.pep.visao;

import br.edu.ifsp.pep.dao.FuncionarioDAO;
import br.edu.ifsp.pep.modelo.Funcionario;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import util.Utilidade;
import util.ValidaCpfCnpj;

public class FuncionarioView extends javax.swing.JDialog {

    private FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
    private List<Funcionario> funcionarios = new ArrayList<>();
    private Utilidade util = new Utilidade(); //exibir mensagens e formatar datas
    //variáveis utilizadas na classe atual
    private boolean alterar = false;
    private Integer codigo;

    public FuncionarioView(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        atualizarTabela();
        //colocando nome do funcionário logado na tela
        lFuncionario.setText(funcionarioDAO.getFuncionarioLogado().getNome());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tFuncionarios = new javax.swing.JTable();
        labTitulo = new javax.swing.JLabel();
        bPesquisar = new javax.swing.JButton();
        labNome = new javax.swing.JLabel();
        labEndereco = new javax.swing.JLabel();
        labCPF = new javax.swing.JLabel();
        labTelefone = new javax.swing.JLabel();
        tfRua = new javax.swing.JTextField();
        tfPesquisar = new javax.swing.JTextField();
        tfCPF = new javax.swing.JFormattedTextField();
        tfTelefone = new javax.swing.JFormattedTextField();
        labLogin = new javax.swing.JLabel();
        tfLogin = new javax.swing.JTextField();
        labSenha = new javax.swing.JLabel();
        tfSenha = new javax.swing.JPasswordField();
        labSalario = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        bExcluir = new javax.swing.JButton();
        bCancelar = new javax.swing.JButton();
        bAlterar = new javax.swing.JButton();
        bSalvar = new javax.swing.JButton();
        tfSalario = new javax.swing.JTextField();
        tfNome = new javax.swing.JTextField();
        labEndereco1 = new javax.swing.JLabel();
        labEndereco2 = new javax.swing.JLabel();
        tfBairro = new javax.swing.JTextField();
        cbEstado = new javax.swing.JComboBox<>();
        labEndereco3 = new javax.swing.JLabel();
        labEndereco4 = new javax.swing.JLabel();
        tfCidade = new javax.swing.JTextField();
        tfNumero = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        labFoto = new javax.swing.JLabel();
        pRodae = new javax.swing.JPanel();
        lFuncionario = new javax.swing.JLabel();
        bTelaInicial = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(217, 217, 217));

        tFuncionarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "CPF", "Telefone", "Salário"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tFuncionarios);

        labTitulo.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        labTitulo.setForeground(new java.awt.Color(69, 95, 68));
        labTitulo.setText("FUNCIONÁRIOS");

        bPesquisar.setBackground(new java.awt.Color(69, 95, 68));
        bPesquisar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bPesquisar.setForeground(new java.awt.Color(255, 255, 255));
        bPesquisar.setText("Pesquisar");
        bPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPesquisarActionPerformed(evt);
            }
        });

        labNome.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labNome.setText("Nome:");

        labEndereco.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labEndereco.setText("Rua:");

        labCPF.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labCPF.setText("CPF:");

        labTelefone.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labTelefone.setText("Telefone:");

        tfRua.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        tfPesquisar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        try {
            tfCPF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        tfCPF.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfCPF.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfCPFFocusLost(evt);
            }
        });

        try {
            tfTelefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)#####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        tfTelefone.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        labLogin.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labLogin.setText("Login:");

        tfLogin.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        labSenha.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labSenha.setText("Senha:");

        tfSenha.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        labSalario.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labSalario.setText("Salário:");

        jPanel4.setLayout(new java.awt.GridLayout(1, 0, 0, 25));

        bExcluir.setBackground(new java.awt.Color(102, 0, 0));
        bExcluir.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bExcluir.setForeground(new java.awt.Color(255, 255, 255));
        bExcluir.setText("Excluir");
        bExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bExcluirActionPerformed(evt);
            }
        });
        jPanel4.add(bExcluir);

        bCancelar.setBackground(new java.awt.Color(102, 102, 102));
        bCancelar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bCancelar.setForeground(new java.awt.Color(255, 255, 255));
        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });
        jPanel4.add(bCancelar);

        bAlterar.setBackground(new java.awt.Color(102, 102, 102));
        bAlterar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bAlterar.setForeground(new java.awt.Color(255, 255, 255));
        bAlterar.setText("Alterar");
        bAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAlterarActionPerformed(evt);
            }
        });
        jPanel4.add(bAlterar);

        bSalvar.setBackground(new java.awt.Color(69, 95, 68));
        bSalvar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bSalvar.setForeground(new java.awt.Color(255, 255, 255));
        bSalvar.setText("Salvar");
        bSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSalvarActionPerformed(evt);
            }
        });
        jPanel4.add(bSalvar);

        tfSalario.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        tfNome.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        labEndereco1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labEndereco1.setText("Nº:");

        labEndereco2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labEndereco2.setText("Bairro:");

        tfBairro.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        cbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" }));

        labEndereco3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labEndereco3.setText("Estado:");

        labEndereco4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labEndereco4.setText("Cidade:");

        tfCidade.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        tfNumero.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tfNumero.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfNumeroFocusLost(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(tfPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 391, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(labLogin)
                                            .addComponent(labNome))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(tfNome)
                                            .addComponent(tfLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(labTelefone)
                                            .addComponent(labCPF)))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(labSenha)
                                            .addComponent(labEndereco))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(tfSenha, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE)
                                            .addComponent(tfRua))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(labSalario)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addComponent(labEndereco1)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(tfNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(labEndereco3)
                                        .addGap(18, 18, 18)
                                        .addComponent(cbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tfTelefone, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tfCPF, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tfSalario, javax.swing.GroupLayout.Alignment.LEADING)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(labEndereco4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tfCidade, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(labEndereco2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfBairro, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(38, 38, 38))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(397, 397, 397)
                        .addComponent(labTitulo)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labTitulo)
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labNome)
                            .addComponent(tfNome, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labCPF)
                            .addComponent(tfCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labLogin)
                            .addComponent(tfLogin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labTelefone)
                            .addComponent(tfTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labSenha)
                            .addComponent(tfSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labSalario)
                            .addComponent(tfSalario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labEndereco)
                            .addComponent(tfRua, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labEndereco1)
                            .addComponent(labEndereco3)
                            .addComponent(cbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labEndereco4)
                            .addComponent(labEndereco2)
                            .addComponent(tfBairro, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfCidade, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        jPanel3.setBackground(new java.awt.Color(69, 95, 68));

        labFoto.setFont(new java.awt.Font("Corbel Light", 0, 52)); // NOI18N
        labFoto.setForeground(new java.awt.Color(184, 236, 135));
        labFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/logo.png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(labFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labFoto)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pRodae.setBackground(new java.awt.Color(154, 198, 109));

        lFuncionario.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lFuncionario.setForeground(new java.awt.Color(69, 95, 68));
        lFuncionario.setText("Gerente ");

        bTelaInicial.setBackground(new java.awt.Color(102, 102, 102));
        bTelaInicial.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bTelaInicial.setForeground(new java.awt.Color(255, 255, 255));
        bTelaInicial.setText("Tela inicial");
        bTelaInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTelaInicialActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pRodaeLayout = new javax.swing.GroupLayout(pRodae);
        pRodae.setLayout(pRodaeLayout);
        pRodaeLayout.setHorizontalGroup(
            pRodaeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pRodaeLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(bTelaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 849, Short.MAX_VALUE)
                .addComponent(lFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );
        pRodaeLayout.setVerticalGroup(
            pRodaeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pRodaeLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(pRodaeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bTelaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lFuncionario))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(pRodae, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pRodae, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1200, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPesquisarActionPerformed
        atualizarTabela();
    }//GEN-LAST:event_bPesquisarActionPerformed

    private void tfCPFFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfCPFFocusLost
        if (!ValidaCpfCnpj.isCPF(tfCPF.getText())) { //validar CPF assim que o campo tfCPF perder o foco
            util.exibirMensagemError("CPF inválido.");
            tfCPF.requestFocus();
        }
    }//GEN-LAST:event_tfCPFFocusLost

    private void bExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bExcluirActionPerformed
        int linha = tFuncionarios.getSelectedRow();
        if (linha == -1) {
            util.exibirMensagemWarning("Selecione uma linha na tabela");
        } else {
            if (util.exibirMensagemConfirmacaoExcluir() == 0) { //deseja excluir?
                Funcionario funcionarioRemover = funcionarios.get(linha);
                funcionarioRemover.setStatus("I");
                funcionarioDAO.alterar(funcionarioRemover);
                util.exibirMensagem("Funcionário excluído");
                atualizarTabela();
                limparCampos();
            }
        }
    }//GEN-LAST:event_bExcluirActionPerformed

    private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
        if ((!tfNome.getText().isEmpty()) || (!tfRua.getText().isEmpty()) || (!tfBairro.getText().isEmpty())
                || (!tfCidade.getText().isEmpty()) || (!tfNumero.getText().isEmpty())
                || (!tfCPF.getText().equals("   .   .   -  ")) || (!tfTelefone.getText().equals("(  )     -    "))
                || (!tfLogin.getText().isEmpty()) || (!tfSenha.getText().isEmpty())) { //se os campos estão preenchidos
            if (util.exibirMensagemConfirmacaoCancelar() == 0) {
                limparCampos();
            }
        } else {
            limparCampos();
        }
    }//GEN-LAST:event_bCancelarActionPerformed

    private void bAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAlterarActionPerformed
        int linha = tFuncionarios.getSelectedRow();
        if (linha == -1) {
            util.exibirMensagemWarning("Selecione uma linha na tabela");
        } else {
            Funcionario funcionarioAlterar = funcionarios.get(linha);
            tfNome.setText(funcionarioAlterar.getNome());
            tfCPF.setText(funcionarioAlterar.getCpf());
            tfRua.setText(funcionarioAlterar.getRua());
            tfNumero.setText(String.valueOf(funcionarioAlterar.getNumero()));
            tfBairro.setText(funcionarioAlterar.getBairro());
            tfCidade.setText(funcionarioAlterar.getCidade());
            cbEstado.setSelectedItem(funcionarioAlterar.getEstado());
            tfLogin.setText(funcionarioAlterar.getLogin());
            tfSalario.setText(String.valueOf(funcionarioAlterar.getSalario()));
            tfSenha.setText(funcionarioAlterar.getSenha());
            tfTelefone.setText(funcionarioAlterar.getTelefone());
            alterar = true;
            tfCPF.setEnabled(false);
            this.codigo = funcionarioAlterar.getCodigo();
        }
    }//GEN-LAST:event_bAlterarActionPerformed

    private void bSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSalvarActionPerformed
        if (tfNome.getText().isEmpty()) {
            util.exibirMensagemWarning("Preencha o nome, por favor!");
            tfNome.requestFocus();
        } else if (tfCPF.getText().equals("   .   .   -  ")) {
            util.exibirMensagemWarning("Preencha o CPF, por favor!");
            tfCPF.requestFocus();
        } else if (tfLogin.getText().isEmpty()) {
            util.exibirMensagemWarning("Preencha o login, por favor!");
            tfLogin.requestFocus();
        } else if (tfTelefone.getText().equals("(  )     -    ")) {
            util.exibirMensagemWarning("Preencha o telefone, por favor!");
            tfTelefone.requestFocus();
        } else if (tfSenha.getText().isEmpty()) {
            util.exibirMensagemWarning("Preencha a senha, por favor!");
            tfSenha.requestFocus();
        } else if (tfRua.getText().isEmpty()) {
            util.exibirMensagemWarning("Preencha a rua, por favor!");
            tfRua.requestFocus();
        } else if (tfCidade.getText().isEmpty()) {
            util.exibirMensagemWarning("Preencha a cidade, por favor!");
            tfCidade.requestFocus();
        } else if (tfBairro.getText().isEmpty()) {
            util.exibirMensagemWarning("Preencha o bairro, por favor!");
            tfBairro.requestFocus();
        } else {
            Funcionario f = new Funcionario();
            f.setCpf(tfCPF.getText());
            f.setRua(tfRua.getText());
            f.setNumero(Integer.valueOf(tfNumero.getText()));
            f.setCidade(tfCidade.getText());
            f.setEstado((String) cbEstado.getSelectedItem());
            f.setBairro(tfBairro.getText());
            f.setLogin(tfLogin.getText());
            f.setNome(tfNome.getText());
            f.setSenha(String.valueOf(tfSenha.getPassword()));
            f.setStatus("A");
            f.setTelefone(tfTelefone.getText());
            if (tfSalario.getText().isEmpty()) {
                f.setSalario(new BigDecimal(0));
            } else {
                try {
                    BigDecimal salario = new BigDecimal(tfSalario.getText());
                    f.setSalario(salario);
                    if (alterar == false) { //adicionar funcionário
                        f.setTipo("F"); //setando tipo funcionário
                        if (funcionarioDAO.buscarPorLogin(tfLogin.getText()) != null) { //validar login existente
                            util.exibirMensagemError("Login já existente, tente outro!");
                        } else if (funcionarioDAO.buscarPorCpf(tfCPF.getText()) != null) { //validar CPF existente
                            util.exibirMensagemError("CPF já cadastrado.");
                        } else {
                            try {
                                funcionarioDAO.inserir(f);
                                util.exibirMensagem("Funcionário adicionado!");
                                limparCampos();
                            } catch (Exception ex) {
                                util.exibirMensagemError("Erro ao adicionar.");
                            }
                        }
                    } else { //alterar funcionário
                        f.setCodigo(codigo);
                        Funcionario anterior = funcionarioDAO.buscarPorCodigo(codigo);
                        f.setTipo(anterior.getTipo());
                        funcionarioDAO.alterar(f);
                        util.exibirMensagem("Funcionário alterado!");
                        alterar = false;
                        limparCampos();
                        tfCPF.setEnabled(true);
                    }
                    atualizarTabela();
                } catch (NumberFormatException ex) {
                    util.exibirMensagemError("Salário inválido.");
                }
            }
        }
    }//GEN-LAST:event_bSalvarActionPerformed

    private void tfNumeroFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfNumeroFocusLost
        try {
            Integer numero = Integer.valueOf(tfNumero.getText()); //validar número da residência
        } catch (NumberFormatException ex) {
            util.exibirMensagemWarning("Insira o número da residência válido");
            tfNumero.requestFocus();
        }
    }//GEN-LAST:event_tfNumeroFocusLost

    private void bTelaInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTelaInicialActionPerformed
        dispose();
    }//GEN-LAST:event_bTelaInicialActionPerformed

    private void atualizarTabela() {
        DefaultTableModel modelo = (DefaultTableModel) tFuncionarios.getModel();
        modelo.setNumRows(0);
        funcionarios.clear();
        funcionarios.addAll(funcionarioDAO.buscarPorNomeEStatus(tfPesquisar.getText(), "A"));
        for (Funcionario f : funcionarios) {
            modelo.addRow(new Object[]{f.getNome(), f.getCpf(), f.getTelefone(), f.getSalario()});
        }
    }

    private void limparCampos() {
        tfCPF.setText("");
        tfRua.setText("");
        tfBairro.setText("");
        tfCidade.setText("");
        tfNumero.setText("");
        cbEstado.setSelectedIndex(0);
        tfLogin.setText("");
        tfNome.setText("");
        tfSalario.setText("");
        tfSenha.setText("");
        tfTelefone.setText("");
    }

//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(FuncionarioView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(FuncionarioView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(FuncionarioView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(FuncionarioView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the dialog */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                FuncionarioView1 dialog = new FuncionarioView1(new javax.swing.JFrame(), true);
//                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
//                    @Override
//                    public void windowClosing(java.awt.event.WindowEvent e) {
//                        System.exit(0);
//                    }
//                });
//                dialog.setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAlterar;
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bExcluir;
    private javax.swing.JButton bPesquisar;
    private javax.swing.JButton bSalvar;
    private javax.swing.JButton bTelaInicial;
    private javax.swing.JComboBox<String> cbEstado;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lFuncionario;
    private javax.swing.JLabel labCPF;
    private javax.swing.JLabel labEndereco;
    private javax.swing.JLabel labEndereco1;
    private javax.swing.JLabel labEndereco2;
    private javax.swing.JLabel labEndereco3;
    private javax.swing.JLabel labEndereco4;
    private javax.swing.JLabel labFoto;
    private javax.swing.JLabel labLogin;
    private javax.swing.JLabel labNome;
    private javax.swing.JLabel labSalario;
    private javax.swing.JLabel labSenha;
    private javax.swing.JLabel labTelefone;
    private javax.swing.JLabel labTitulo;
    private javax.swing.JPanel pRodae;
    private javax.swing.JTable tFuncionarios;
    private javax.swing.JTextField tfBairro;
    private javax.swing.JFormattedTextField tfCPF;
    private javax.swing.JTextField tfCidade;
    private javax.swing.JTextField tfLogin;
    private javax.swing.JTextField tfNome;
    private javax.swing.JTextField tfNumero;
    private javax.swing.JTextField tfPesquisar;
    private javax.swing.JTextField tfRua;
    private javax.swing.JTextField tfSalario;
    private javax.swing.JPasswordField tfSenha;
    private javax.swing.JFormattedTextField tfTelefone;
    // End of variables declaration//GEN-END:variables
}
