package br.edu.ifsp.pep.visao;

import br.edu.ifsp.pep.dao.CaixaDAO;
import br.edu.ifsp.pep.dao.DespesaDAO;
import br.edu.ifsp.pep.dao.FuncionarioDAO;
import br.edu.ifsp.pep.dao.TipoDespesaDAO;
import br.edu.ifsp.pep.modelo.Despesa;
import br.edu.ifsp.pep.modelo.TipoDespesa;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import util.Utilidade;

public class DespesaView extends javax.swing.JDialog {

    private TipoDespesaDAO tipoDespesaDAO = new TipoDespesaDAO();
    private CaixaDAO caixaDAO = new CaixaDAO();
    private FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
    private DespesaDAO despesaDAO = new DespesaDAO();
    private List<TipoDespesa> tipoDespesas = new ArrayList<>();
    private List<Despesa> despesas = new ArrayList<>();
    private Utilidade util = new Utilidade();//exibir mensagens e formatar datas
    //variáveis utilizadas na classe atual
    private boolean alterar1 = false; //alterar do tabbedPane1
    private boolean alterar2 = false; //alterar do tabbedPane2
    private Long codigoDespesa; //código para alterar a despesa
    private Integer codigoTipo; //código para alterar o tipo de despesa

    public DespesaView(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.setLocationRelativeTo(null);
        atualizarTabelaDespesas();
        atualizarTabelaTipos();
        this.carregarTiposDespesas();
        //colocando nome do funcionário logado na tela
        lFuncionario.setText(funcionarioDAO.getFuncionarioLogado().getNome());
        lFuncionario1.setText(funcionarioDAO.getFuncionarioLogado().getNome());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        tab1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tDespesas = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        tfPesquisarDespesa = new javax.swing.JTextField();
        bPesquisarDespesa = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        bExcluirDespesa = new javax.swing.JButton();
        bCancelarDespesa = new javax.swing.JButton();
        bAlterarDespesa = new javax.swing.JButton();
        bSalvarDespesa = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        cbFormaPagamento = new javax.swing.JComboBox<>();
        tfValor = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        cbTipoDespesa = new javax.swing.JComboBox<>();
        jPanel6 = new javax.swing.JPanel();
        lFuncionario = new javax.swing.JLabel();
        bTelaInicial = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tTipos = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        tfPesquisarTipo = new javax.swing.JTextField();
        bPesquisarTipo = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        tfDescricao = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        bExcluirTipoDespesa = new javax.swing.JButton();
        bCancelarTipoDespesa = new javax.swing.JButton();
        bAlterarTipoDespesa = new javax.swing.JButton();
        bSalvarTipoDespesa = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        lFuncionario1 = new javax.swing.JLabel();
        bTelaInicial1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        jPanel3.setBackground(new java.awt.Color(69, 95, 68));

        jLabel1.setFont(new java.awt.Font("Corbel Light", 0, 52)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(184, 236, 135));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/logo.png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(217, 217, 217));

        tDespesas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tipo de Despesa", "Valor", "Pagamento", "Data de lançamento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tDespesas);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(69, 95, 68));
        jLabel4.setText("DESPESAS PAGAS");

        bPesquisarDespesa.setBackground(new java.awt.Color(69, 95, 68));
        bPesquisarDespesa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bPesquisarDespesa.setForeground(new java.awt.Color(255, 255, 255));
        bPesquisarDespesa.setText("Pesquisar");
        bPesquisarDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPesquisarDespesaActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText("Valor:");

        jPanel4.setLayout(new java.awt.GridLayout(1, 0, 0, 25));

        bExcluirDespesa.setBackground(new java.awt.Color(102, 0, 0));
        bExcluirDespesa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bExcluirDespesa.setForeground(new java.awt.Color(255, 255, 255));
        bExcluirDespesa.setText("Excluir");
        bExcluirDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bExcluirDespesaActionPerformed(evt);
            }
        });
        jPanel4.add(bExcluirDespesa);

        bCancelarDespesa.setBackground(new java.awt.Color(102, 102, 102));
        bCancelarDespesa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bCancelarDespesa.setForeground(new java.awt.Color(255, 255, 255));
        bCancelarDespesa.setText("Cancelar");
        bCancelarDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarDespesaActionPerformed(evt);
            }
        });
        jPanel4.add(bCancelarDespesa);

        bAlterarDespesa.setBackground(new java.awt.Color(102, 102, 102));
        bAlterarDespesa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bAlterarDespesa.setForeground(new java.awt.Color(255, 255, 255));
        bAlterarDespesa.setText("Alterar");
        bAlterarDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAlterarDespesaActionPerformed(evt);
            }
        });
        jPanel4.add(bAlterarDespesa);

        bSalvarDespesa.setBackground(new java.awt.Color(69, 95, 68));
        bSalvarDespesa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bSalvarDespesa.setForeground(new java.awt.Color(255, 255, 255));
        bSalvarDespesa.setText("Salvar");
        bSalvarDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSalvarDespesaActionPerformed(evt);
            }
        });
        jPanel4.add(bSalvarDespesa);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setText("Forma de pagamento:");

        cbFormaPagamento.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cbFormaPagamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cartão de Crédito", "Cartão de Débito", "Dinheiro", "Pix" }));

        tfValor.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel11.setText("Tipo de despesa:");

        cbTipoDespesa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(460, 460, 460))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(tfPesquisarDespesa, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bPesquisarDespesa, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(62, 62, 62)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cbFormaPagamento, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(tfValor, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(58, 58, 58)
                                .addComponent(cbTipoDespesa, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1271, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(tfPesquisarDespesa, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bPesquisarDespesa, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(tfValor, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(cbFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbTipoDespesa, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        jPanel6.setBackground(new java.awt.Color(154, 198, 109));

        lFuncionario.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lFuncionario.setForeground(new java.awt.Color(69, 95, 68));
        lFuncionario.setText("Gerente ");

        bTelaInicial.setBackground(new java.awt.Color(102, 102, 102));
        bTelaInicial.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bTelaInicial.setForeground(new java.awt.Color(255, 255, 255));
        bTelaInicial.setText("Tela inicial");
        bTelaInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTelaInicialActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(bTelaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 971, Short.MAX_VALUE)
                .addComponent(lFuncionario)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lFuncionario)
                    .addComponent(bTelaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout tab1Layout = new javax.swing.GroupLayout(tab1);
        tab1.setLayout(tab1Layout);
        tab1Layout.setHorizontalGroup(
            tab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tab1Layout.createSequentialGroup()
                .addGroup(tab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        tab1Layout.setVerticalGroup(
            tab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tab1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Despesas Pagas", tab1);

        jPanel8.setBackground(new java.awt.Color(217, 217, 217));

        tTipos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Descrição"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tTipos);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(69, 95, 68));
        jLabel5.setText("TIPOS DE DESPESAS");

        bPesquisarTipo.setBackground(new java.awt.Color(69, 95, 68));
        bPesquisarTipo.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bPesquisarTipo.setForeground(new java.awt.Color(255, 255, 255));
        bPesquisarTipo.setText("Pesquisar");
        bPesquisarTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPesquisarTipoActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setText("Descrição:");

        jPanel9.setLayout(new java.awt.GridLayout(1, 0, 0, 25));

        bExcluirTipoDespesa.setBackground(new java.awt.Color(102, 0, 0));
        bExcluirTipoDespesa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bExcluirTipoDespesa.setForeground(new java.awt.Color(255, 255, 255));
        bExcluirTipoDespesa.setText("Excluir");
        bExcluirTipoDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bExcluirTipoDespesaActionPerformed(evt);
            }
        });
        jPanel9.add(bExcluirTipoDespesa);

        bCancelarTipoDespesa.setBackground(new java.awt.Color(102, 102, 102));
        bCancelarTipoDespesa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bCancelarTipoDespesa.setForeground(new java.awt.Color(255, 255, 255));
        bCancelarTipoDespesa.setText("Cancelar");
        bCancelarTipoDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarTipoDespesaActionPerformed(evt);
            }
        });
        jPanel9.add(bCancelarTipoDespesa);

        bAlterarTipoDespesa.setBackground(new java.awt.Color(102, 102, 102));
        bAlterarTipoDespesa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bAlterarTipoDespesa.setForeground(new java.awt.Color(255, 255, 255));
        bAlterarTipoDespesa.setText("Alterar");
        bAlterarTipoDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAlterarTipoDespesaActionPerformed(evt);
            }
        });
        jPanel9.add(bAlterarTipoDespesa);

        bSalvarTipoDespesa.setBackground(new java.awt.Color(69, 95, 68));
        bSalvarTipoDespesa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bSalvarTipoDespesa.setForeground(new java.awt.Color(255, 255, 255));
        bSalvarTipoDespesa.setText("Salvar");
        bSalvarTipoDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSalvarTipoDespesaActionPerformed(evt);
            }
        });
        jPanel9.add(bSalvarTipoDespesa);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(460, 460, 460))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(tfPesquisarTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bPesquisarTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(tfDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(84, 84, 84))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 1271, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(tfPesquisarTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bPesquisarTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tfDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        jPanel11.setBackground(new java.awt.Color(154, 198, 109));

        lFuncionario1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lFuncionario1.setForeground(new java.awt.Color(69, 95, 68));
        lFuncionario1.setText("Gerente ");

        bTelaInicial1.setBackground(new java.awt.Color(102, 102, 102));
        bTelaInicial1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bTelaInicial1.setForeground(new java.awt.Color(255, 255, 255));
        bTelaInicial1.setText("Tela inicial");
        bTelaInicial1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTelaInicial1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(bTelaInicial1, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lFuncionario1)
                .addGap(30, 30, 30))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lFuncionario1)
                    .addComponent(bTelaInicial1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 635, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Tipos de Despesas", jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 1282, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 667, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bTelaInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTelaInicialActionPerformed
        dispose();
    }//GEN-LAST:event_bTelaInicialActionPerformed

    private void bSalvarDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSalvarDespesaActionPerformed
        if (tfValor.getText().isEmpty()) {
            util.exibirMensagemWarning("Preencha o valor, por favor!");
            tfValor.requestFocus();
        } else {
            Calendar c = Calendar.getInstance();
            Despesa d = new Despesa(); //despesa que será adicionada/alterada

            d.setCaixa(caixaDAO.getCaixa());
            d.setDataLancamento(c.getTime());
            d.setFormaPagamento((String) cbFormaPagamento.getSelectedItem());
            d.setStatus("A");
            d.setTipoDespesa((TipoDespesa) cbTipoDespesa.getSelectedItem());
            d.setValor(new BigDecimal(tfValor.getText()));

            if (alterar1 == false) { //adicionando despesa
                try {
                    despesaDAO.inserir(d);
                    caixaDAO.atualizaCaixaDespesa(funcionarioDAO.getFuncionarioLogado().getCodigo(), d.getValor());
                    util.exibirMensagem("Despesa adicionada!");
                    atualizarTabelaDespesas();
                    limparCampos();
                } catch (Exception ex) {
                    util.exibirMensagemError("Erro ao adicionar.");
                }
            } else { //alterando despesa
                d.setCodigo(codigoDespesa);
                despesaDAO.alterar(d);
                util.exibirMensagem("Despesa alterada!");
                alterar1 = false;
                atualizarTabelaDespesas();
                limparCampos();
            }
        }
    }//GEN-LAST:event_bSalvarDespesaActionPerformed

    private void bAlterarDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAlterarDespesaActionPerformed
        int linha = tDespesas.getSelectedRow();
        if (linha == -1) {
            util.exibirMensagemWarning("Selecione uma linha na tabela");
        } else {
            Despesa despesaAlterar = despesas.get(linha);
            tfValor.setText(String.valueOf(despesaAlterar.getValor()));
            cbFormaPagamento.setSelectedItem(despesaAlterar.getFormaPagamento());
            cbTipoDespesa.setSelectedItem(despesaAlterar.getTipoDespesa());
            alterar1 = true;
            this.codigoDespesa = despesaAlterar.getCodigo();
        }
    }//GEN-LAST:event_bAlterarDespesaActionPerformed

    private void bCancelarDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarDespesaActionPerformed
        if ((!tfValor.getText().isEmpty())) { //se os campos estão preenchidos
            if (util.exibirMensagemConfirmacaoCancelar() == 0) { //pergunta se deseja realmente cancelar
                limparCampos();
            }
        } else {
            limparCampos();
        }
    }//GEN-LAST:event_bCancelarDespesaActionPerformed

    private void bExcluirDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bExcluirDespesaActionPerformed
        int linha = tDespesas.getSelectedRow();
        if (linha == -1) {
            util.exibirMensagemWarning("Selecione uma linha na tabela");
        } else {
            if (util.exibirMensagemConfirmacaoExcluir() == 0) { //pergunta se deseja realmente excluir
                Despesa despesaRemover = despesas.get(linha);
                despesaRemover.setStatus("I"); //altera o status para inativo
                despesaDAO.alterar(despesaRemover);
                util.exibirMensagem("Despesa excluída");
                atualizarTabelaDespesas();
            }
        }
    }//GEN-LAST:event_bExcluirDespesaActionPerformed

    private void bPesquisarDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPesquisarDespesaActionPerformed
        atualizarTabelaDespesas();
    }//GEN-LAST:event_bPesquisarDespesaActionPerformed

    private void bPesquisarTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPesquisarTipoActionPerformed
        atualizarTabelaTipos();
    }//GEN-LAST:event_bPesquisarTipoActionPerformed

    private void bExcluirTipoDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bExcluirTipoDespesaActionPerformed
        int linha = tTipos.getSelectedRow();
        if (linha == -1) {
            util.exibirMensagemWarning("Selecione uma linha na tabela");
        } else {
            if (util.exibirMensagemConfirmacaoExcluir() == 0) { //deseja realmente excluir?
                TipoDespesa tipoDespesaRemover = tipoDespesas.get(linha);
                tipoDespesaRemover.setStatus("I");
                tipoDespesaDAO.alterar(tipoDespesaRemover);
                util.exibirMensagem("Tipo de despesa excluído");
                atualizarTabelaTipos();
                tfDescricao.setText("");
            }
        }
    }//GEN-LAST:event_bExcluirTipoDespesaActionPerformed

    private void bCancelarTipoDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarTipoDespesaActionPerformed
        if ((!tfDescricao.getText().isEmpty())) { //se os campos estão preenchidos
            if (util.exibirMensagemConfirmacaoCancelar() == 0) { //pergunta se deseja mesmo cancelar
                tfDescricao.setText(""); //limpa o campo
            }
        } else {
            tfDescricao.setText(""); //limpa o campo
        }
    }//GEN-LAST:event_bCancelarTipoDespesaActionPerformed

    private void bAlterarTipoDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAlterarTipoDespesaActionPerformed
        int linha = tTipos.getSelectedRow();
        if (linha == -1) {
            util.exibirMensagemWarning("Selecione uma linha na tabela");
        } else {
            TipoDespesa tipoDespesaAlterar = tipoDespesas.get(linha);
            tfDescricao.setText(tipoDespesaAlterar.getDescricao());
            alterar2 = true;
            this.codigoTipo = tipoDespesaAlterar.getCodigo();
        }
    }//GEN-LAST:event_bAlterarTipoDespesaActionPerformed

    private void bSalvarTipoDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSalvarTipoDespesaActionPerformed
        if (tfDescricao.getText().isEmpty()) {
            util.exibirMensagemWarning("Preencha a descrição, por favor!");
            tfDescricao.requestFocus();
        } else {
            TipoDespesa td = new TipoDespesa();
            td.setStatus("A");
            td.setDescricao(tfDescricao.getText());
            if (alterar2 == false) { //adicionando tipo despesa
                try {
                    tipoDespesaDAO.inserir(td);
                    util.exibirMensagem("Tipo de despesa adicionado!");
                    atualizarTabelaTipos();
                    tfDescricao.setText("");
                } catch (Exception ex) {
                    util.exibirMensagemError("Erro ao adicionar.");
                }
            } else { //alterando tipo de despesa
                td.setCodigo(codigoTipo);
                tipoDespesaDAO.alterar(td);
                util.exibirMensagem("Tipo de despesa alterado!");
                alterar2 = false;
                atualizarTabelaTipos();
                tfDescricao.setText("");
            }
        }
    }//GEN-LAST:event_bSalvarTipoDespesaActionPerformed

    private void bTelaInicial1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTelaInicial1ActionPerformed
        dispose();
    }//GEN-LAST:event_bTelaInicial1ActionPerformed

    private void limparCampos() {
        tfValor.setText("");
        cbFormaPagamento.setSelectedIndex(0);
        cbTipoDespesa.setSelectedIndex(0);
    }

    private void atualizarTabelaDespesas() {
        DefaultTableModel modelo = (DefaultTableModel) tDespesas.getModel();
        modelo.setNumRows(0);
        despesas.clear();
        despesas.addAll(despesaDAO.buscarPorDescricaoEStatus(tfPesquisarDespesa.getText(), "A"));
        for (Despesa d : despesas) {
            modelo.addRow(new Object[]{d.getTipoDespesa().getDescricao(), d.getValor(), d.getFormaPagamento(), util.formatarDataBR(d.getDataLancamento())});
        }
    }

    private void atualizarTabelaTipos() {
        DefaultTableModel modelo = (DefaultTableModel) tTipos.getModel();
        modelo.setNumRows(0);
        tipoDespesas.clear();
        tipoDespesas.addAll(tipoDespesaDAO.buscarPorDescricaoEStatus(tfPesquisarDespesa.getText(), "A"));
        for (TipoDespesa td : tipoDespesas) {
            modelo.addRow(new Object[]{td.getCodigo(), td.getDescricao()});
        }

    }

    private void carregarTiposDespesas() {
        DefaultComboBoxModel modelo = (DefaultComboBoxModel) cbTipoDespesa.getModel();
        modelo.removeAllElements();
        tipoDespesas.clear();
        tipoDespesas.addAll(tipoDespesaDAO.buscarTodos());
        for (TipoDespesa td : tipoDespesas) {
            modelo.addElement(td);
        }
        cbTipoDespesa.setSelectedIndex(0);
    }

//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(DespesaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(DespesaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(DespesaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(DespesaView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new DespesaView().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAlterarDespesa;
    private javax.swing.JButton bAlterarTipoDespesa;
    private javax.swing.JButton bCancelarDespesa;
    private javax.swing.JButton bCancelarTipoDespesa;
    private javax.swing.JButton bExcluirDespesa;
    private javax.swing.JButton bExcluirTipoDespesa;
    private javax.swing.JButton bPesquisarDespesa;
    private javax.swing.JButton bPesquisarTipo;
    private javax.swing.JButton bSalvarDespesa;
    private javax.swing.JButton bSalvarTipoDespesa;
    private javax.swing.JButton bTelaInicial;
    private javax.swing.JButton bTelaInicial1;
    private javax.swing.JComboBox<String> cbFormaPagamento;
    private javax.swing.JComboBox<String> cbTipoDespesa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lFuncionario;
    private javax.swing.JLabel lFuncionario1;
    private javax.swing.JTable tDespesas;
    private javax.swing.JTable tTipos;
    private javax.swing.JPanel tab1;
    private javax.swing.JTextField tfDescricao;
    private javax.swing.JTextField tfPesquisarDespesa;
    private javax.swing.JTextField tfPesquisarTipo;
    private javax.swing.JTextField tfValor;
    // End of variables declaration//GEN-END:variables
}
