package br.edu.ifsp.pep.visao;

import br.edu.ifsp.pep.dao.CaixaDAO;
import br.edu.ifsp.pep.dao.FuncionarioDAO;
import br.edu.ifsp.pep.dao.ProdutoDAO;
import br.edu.ifsp.pep.dao.VendaDAO;
import br.edu.ifsp.pep.modelo.Cliente;
import br.edu.ifsp.pep.modelo.ItemVenda;
import br.edu.ifsp.pep.modelo.Produto;
import br.edu.ifsp.pep.modelo.Venda;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import util.Utilidade;

public class VendaView extends javax.swing.JDialog {

    private ProdutoDAO produtoDAO = new ProdutoDAO();
    private FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
    private VendaDAO vendaDAO = new VendaDAO();
    private CaixaDAO caixaDAO = new CaixaDAO();
    private List<Produto> produtos = new ArrayList<>();
    private List<ItemVenda> carrinho = new ArrayList<>();
    private Utilidade util = new Utilidade(); //usado para enviar mensagens e formatar datas
    //variáveis utilizadas na classe atual
    private Cliente cliente = null;
    private BigDecimal totalVenda = new BigDecimal(0);

    public VendaView(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.setLocationRelativeTo(null);
        atualizarTotal(new BigDecimal(0));
        tfCliente.setEditable(false); //bloquear o campo de cliente, só adiciona se clicar pelo botão
        atualizarTabelaProdutos();
        lFuncionario.setText(funcionarioDAO.getFuncionarioLogado().getNome());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        pRodae = new javax.swing.JPanel();
        lFuncionario = new javax.swing.JLabel();
        bTelaInicial = new javax.swing.JButton();
        pCorpo = new javax.swing.JPanel();
        tfQuantidade = new javax.swing.JTextField();
        bPesquisarCliente = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        labTotal = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        cbFormaPagamento = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tCarrinho = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        tProdutos = new javax.swing.JTable();
        bCancelarProduto = new javax.swing.JButton();
        tfCliente = new javax.swing.JTextField();
        bCancelarVenda = new javax.swing.JButton();
        bAdicionar = new javax.swing.JButton();
        bConcluirVenda = new javax.swing.JButton();
        tfPesquisar = new javax.swing.JTextField();
        bPesquisar = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        pCabecalho = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        pRodae.setBackground(new java.awt.Color(154, 198, 109));

        lFuncionario.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lFuncionario.setForeground(new java.awt.Color(69, 95, 68));
        lFuncionario.setText("Gerente ");

        bTelaInicial.setBackground(new java.awt.Color(102, 102, 102));
        bTelaInicial.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bTelaInicial.setForeground(new java.awt.Color(255, 255, 255));
        bTelaInicial.setText("Tela inicial");
        bTelaInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTelaInicialActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pRodaeLayout = new javax.swing.GroupLayout(pRodae);
        pRodae.setLayout(pRodaeLayout);
        pRodaeLayout.setHorizontalGroup(
            pRodaeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pRodaeLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(bTelaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 925, Short.MAX_VALUE)
                .addComponent(lFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pRodaeLayout.setVerticalGroup(
            pRodaeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pRodaeLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(pRodaeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bTelaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lFuncionario))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pRodae, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pRodae, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pCorpo.setBackground(new java.awt.Color(217, 217, 217));

        tfQuantidade.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        bPesquisarCliente.setBackground(new java.awt.Color(69, 95, 68));
        bPesquisarCliente.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bPesquisarCliente.setForeground(new java.awt.Color(255, 255, 255));
        bPesquisarCliente.setText("Pesquisar");
        bPesquisarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPesquisarClienteActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setText("Total: ");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel8.setText("Cliente:");

        labTotal.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        labTotal.setForeground(new java.awt.Color(69, 95, 68));
        labTotal.setText("R$30,00");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setText("Forma de pagamento:");

        cbFormaPagamento.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cbFormaPagamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cartão de Crédito", "Cartão de Débito", "Dinheiro", "Pix" }));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(69, 95, 68));
        jLabel11.setText("Carrinho:");

        tCarrinho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome", "Valor", "Quantidade", "Valor Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tCarrinho.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(tCarrinho);

        tProdutos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tProdutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome", "Valor", "Quantidade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tProdutos.getTableHeader().setReorderingAllowed(false);
        jScrollPane4.setViewportView(tProdutos);

        bCancelarProduto.setBackground(new java.awt.Color(102, 102, 102));
        bCancelarProduto.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bCancelarProduto.setForeground(new java.awt.Color(255, 255, 255));
        bCancelarProduto.setText("Cancelar produto");
        bCancelarProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarProdutoActionPerformed(evt);
            }
        });

        bCancelarVenda.setBackground(new java.awt.Color(102, 0, 0));
        bCancelarVenda.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bCancelarVenda.setForeground(new java.awt.Color(255, 255, 255));
        bCancelarVenda.setText("Cancelar venda");
        bCancelarVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarVendaActionPerformed(evt);
            }
        });

        bAdicionar.setBackground(new java.awt.Color(69, 95, 68));
        bAdicionar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bAdicionar.setForeground(new java.awt.Color(255, 255, 255));
        bAdicionar.setText("Adicionar");
        bAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAdicionarActionPerformed(evt);
            }
        });

        bConcluirVenda.setBackground(new java.awt.Color(69, 95, 68));
        bConcluirVenda.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bConcluirVenda.setForeground(new java.awt.Color(255, 255, 255));
        bConcluirVenda.setText("Concluir venda");
        bConcluirVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bConcluirVendaActionPerformed(evt);
            }
        });

        bPesquisar.setBackground(new java.awt.Color(69, 95, 68));
        bPesquisar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bPesquisar.setForeground(new java.awt.Color(255, 255, 255));
        bPesquisar.setText("Pesquisar");
        bPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPesquisarActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel9.setText("Quantidade: ");

        javax.swing.GroupLayout pCorpoLayout = new javax.swing.GroupLayout(pCorpo);
        pCorpo.setLayout(pCorpoLayout);
        pCorpoLayout.setHorizontalGroup(
            pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCorpoLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pCorpoLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(tfPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(79, 79, 79))
                    .addGroup(pCorpoLayout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bAdicionar, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(82, 82, 82))
                    .addGroup(pCorpoLayout.createSequentialGroup()
                        .addGroup(pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pCorpoLayout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tfCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bPesquisarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGroup(pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pCorpoLayout.createSequentialGroup()
                        .addComponent(bCancelarVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bConcluirVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pCorpoLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(26, 26, 26)
                        .addComponent(cbFormaPagamento, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel11)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pCorpoLayout.createSequentialGroup()
                        .addComponent(bCancelarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(labTotal))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 547, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(84, 84, 84))
        );
        pCorpoLayout.setVerticalGroup(
            pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCorpoLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11)
                    .addGroup(pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tfPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(bPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(12, 12, 12)
                .addGroup(pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pCorpoLayout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel7)
                                .addComponent(labTotal))
                            .addComponent(bCancelarProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(cbFormaPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bAdicionar, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addGroup(pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bConcluirVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pCorpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(bCancelarVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(bPesquisarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(tfCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel8)))
                .addGap(26, 26, 26))
        );

        pCabecalho.setBackground(new java.awt.Color(69, 95, 68));

        jLabel1.setFont(new java.awt.Font("Corbel Light", 0, 52)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(184, 236, 135));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/logo.png"))); // NOI18N

        javax.swing.GroupLayout pCabecalhoLayout = new javax.swing.GroupLayout(pCabecalho);
        pCabecalho.setLayout(pCabecalhoLayout);
        pCabecalhoLayout.setHorizontalGroup(
            pCabecalhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCabecalhoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(809, Short.MAX_VALUE))
        );
        pCabecalhoLayout.setVerticalGroup(
            pCabecalhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pCabecalhoLayout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pCabecalho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(pCorpo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pCabecalho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pCorpo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bTelaInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTelaInicialActionPerformed
        dispose();
    }//GEN-LAST:event_bTelaInicialActionPerformed

    private void bPesquisarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPesquisarClienteActionPerformed
        PesquisarClienteView tela = new PesquisarClienteView(this, true);
        tela.setVisible(true);
        if (tela.isSelecionou()) {
            cliente = tela.getCliente();
            tfCliente.setText(cliente.getNome());
        }
    }//GEN-LAST:event_bPesquisarClienteActionPerformed

    private void bCancelarProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarProdutoActionPerformed
        int linha = tCarrinho.getSelectedRow();
        if (linha == -1) {
            util.exibirMensagemWarning("Selecione uma linha na tabela.");
        } else {
            if (util.exibirMensagemConfirmacaoExcluir() == 0) {
                ItemVenda iv = carrinho.get(linha);
                carrinho.remove(linha);
                atualizarTabelaCarrinho();
                totalVenda = totalVenda.subtract(iv.getValor());
                atualizarTotal(totalVenda);
            }
        }
    }//GEN-LAST:event_bCancelarProdutoActionPerformed

    private void bCancelarVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarVendaActionPerformed
        if (util.exibirMensagemConfirmacaoCancelar() == 0) {
            limparCampos();
        }
    }//GEN-LAST:event_bCancelarVendaActionPerformed

    private void bAdicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAdicionarActionPerformed
        int linha = tProdutos.getSelectedRow();
        if (linha == -1) {
            util.exibirMensagemWarning("Selecione uma linha na tabela.");
        } else if (tfQuantidade.getText().isEmpty()) {
            util.exibirMensagemWarning("Preencha a quantidade (kg ou unidade), por favor!");
        } else {
            String quantidade = tfQuantidade.getText();
            if (tfQuantidade.getText().contains(",")) { //se escreveu a quantidade no formato: 5,7
                quantidade = tfQuantidade.getText().replace(",", "."); //substitui , por . (evita erros)
            }
            BigDecimal qntd = new BigDecimal(quantidade);
            if (qntd.compareTo(new BigDecimal(0)) == 0 || qntd.compareTo(new BigDecimal(0)) == -1) {
                util.exibirMensagem("A quantidade deve ser maior que zero");
            } else {
                Produto produto = produtos.get(linha);
                try {
                    BigDecimal quantidadeBigDecimal = new BigDecimal(quantidade);
                    if (produto.getQuantidade().compareTo(quantidadeBigDecimal) == -1) { //se a quantidade em estoque é menor que o valor desejado
                        util.exibirMensagemError("Quantidade em estoque insuficiente.");
                    } else {
                        ItemVenda iv = new ItemVenda();
                        iv.setProduto(produto);
                        iv.setQuantidade(quantidadeBigDecimal);
                        BigDecimal total = quantidadeBigDecimal.multiply(produto.getValorVenda());
                        iv.setValor(total);
                        carrinho.add(iv);
                        atualizarTabelaCarrinho();
                        tfQuantidade.setText("");
                        totalVenda = totalVenda.add(total);
                        atualizarTotal(totalVenda);
                    }
                } catch (NumberFormatException ex) {
                    util.exibirMensagemWarning("Insira uma quantidade válida!");
                }
            }
        }
    }//GEN-LAST:event_bAdicionarActionPerformed

    private void bConcluirVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bConcluirVendaActionPerformed
        if (carrinho.isEmpty()) {
            util.exibirMensagemWarning("Adicione algum item ao carrinho!");
        } else {
            Calendar c = Calendar.getInstance();
            Venda v = new Venda();
            v.setCaixa(caixaDAO.buscarAbertoFuncionario(funcionarioDAO.getFuncionarioLogado().getCodigo()));
            v.setDataVenda(c.getTime());
            v.setFormaPagamento(String.valueOf(cbFormaPagamento.getSelectedItem()));
            BigDecimal valor = new BigDecimal(0);
            for (ItemVenda iv : carrinho) {
                valor = valor.add(iv.getValor());
            }
            v.setValorTotal(valor);
            for (ItemVenda iv : carrinho) { //setando venda em todos os itens de venda
                iv.setVenda(v);
            }
            v.setItemVenda(carrinho);
            try {
                vendaDAO.inserir(v);
                caixaDAO.atualizaCaixaVenda(funcionarioDAO.getFuncionarioLogado().getCodigo(), v.getValorTotal());
                util.exibirMensagem("Venda realizada com sucesso!");
                totalVenda = new BigDecimal(0);
                atualizarTabelaProdutos();
                limparCampos();
            } catch (Exception ex) {
                Logger.getLogger(VendaView.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_bConcluirVendaActionPerformed

    private void bPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPesquisarActionPerformed
        atualizarTabelaProdutos();
    }//GEN-LAST:event_bPesquisarActionPerformed

    private void atualizarTabelaProdutos() {
        DefaultTableModel modelo = (DefaultTableModel) tProdutos.getModel();
        modelo.setNumRows(0);
        produtos.clear();
        produtos.addAll(produtoDAO.buscarPorNomeEStatus(tfPesquisar.getText(), "A"));
        for (Produto p : produtos) {
            modelo.addRow(new Object[]{p.getCodigo(), p.getNome(), p.getValorVenda(), p.getQuantidade()});
        }
    }

    private void atualizarTabelaCarrinho() {
        DefaultTableModel modelo = (DefaultTableModel) tCarrinho.getModel();
        modelo.setNumRows(0);
        for (ItemVenda iv : carrinho) {
            modelo.addRow(new Object[]{iv.getProduto().getCodigo(), iv.getProduto().getNome(), iv.getProduto().getValorVenda(), iv.getQuantidade(), util.formatarValor(iv.getValor())});
        }
    }

    private void limparCampos() {
        tfQuantidade.setText("");
        tfCliente.setText("");
        cbFormaPagamento.setSelectedIndex(0);
        carrinho.clear();
        atualizarTabelaCarrinho();
        atualizarTotal(new BigDecimal(0));
    }

    private void atualizarTotal(BigDecimal valor) {
        labTotal.setText(util.formatarValor(valor));
    }

//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(VendaView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(VendaView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(VendaView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(VendaView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the dialog */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                VendaView1 dialog = new VendaView1(new javax.swing.JFrame(), true);
//                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
//                    @Override
//                    public void windowClosing(java.awt.event.WindowEvent e) {
//                        System.exit(0);
//                    }
//                });
//                dialog.setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAdicionar;
    private javax.swing.JButton bCancelarProduto;
    private javax.swing.JButton bCancelarVenda;
    private javax.swing.JButton bConcluirVenda;
    private javax.swing.JButton bPesquisar;
    private javax.swing.JButton bPesquisarCliente;
    private javax.swing.JButton bTelaInicial;
    private javax.swing.JComboBox<String> cbFormaPagamento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel lFuncionario;
    private javax.swing.JLabel labTotal;
    private javax.swing.JPanel pCabecalho;
    private javax.swing.JPanel pCorpo;
    private javax.swing.JPanel pRodae;
    private javax.swing.JTable tCarrinho;
    private javax.swing.JTable tProdutos;
    private javax.swing.JTextField tfCliente;
    private javax.swing.JTextField tfPesquisar;
    private javax.swing.JTextField tfQuantidade;
    // End of variables declaration//GEN-END:variables
}
