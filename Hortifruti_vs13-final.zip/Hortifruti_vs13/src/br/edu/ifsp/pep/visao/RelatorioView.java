package br.edu.ifsp.pep.visao;

import br.edu.ifsp.pep.dao.DespesaDAO;
import br.edu.ifsp.pep.dao.FuncionarioDAO;
import br.edu.ifsp.pep.dao.VendaDAO;
import br.edu.ifsp.pep.modelo.Despesa;
import br.edu.ifsp.pep.modelo.Venda;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
import util.Utilidade;

public class RelatorioView extends javax.swing.JFrame {

    private VendaDAO vendaDAO = new VendaDAO();
    private FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
    private DespesaDAO despesaDAO = new DespesaDAO();
    private List<Venda> vendas = new ArrayList<>();
    private List<Venda> entradas = new ArrayList<>();
    private List<Despesa> saidas = new ArrayList<>();
    private Utilidade util = new Utilidade(); //para exibir mensagens e formatar datas

    public RelatorioView() {
        initComponents();
        this.setLocationRelativeTo(null);
        Calendar c = Calendar.getInstance();
        lFuncionario.setText(funcionarioDAO.getFuncionarioLogado().getNome());
        lFuncionario1.setText(funcionarioDAO.getFuncionarioLogado().getNome());
        dcInicio1.setMaxSelectableDate(c.getTime());
        dcFim1.setMaxSelectableDate(c.getTime());
        dcInicio2.setMaxSelectableDate(c.getTime());
        dcFim2.setMaxSelectableDate(c.getTime());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        tab1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tVendas = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        bBuscar1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        bGerarRelatorio1 = new javax.swing.JButton();
        dcInicio1 = new com.toedter.calendar.JDateChooser();
        dcFim1 = new com.toedter.calendar.JDateChooser();
        labNome = new javax.swing.JLabel();
        labNome1 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        lFuncionario = new javax.swing.JLabel();
        bTelaInicial = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tSaidas = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        labNome2 = new javax.swing.JLabel();
        dcInicio2 = new com.toedter.calendar.JDateChooser();
        labNome3 = new javax.swing.JLabel();
        dcFim2 = new com.toedter.calendar.JDateChooser();
        bBuscar2 = new javax.swing.JButton();
        labNome4 = new javax.swing.JLabel();
        labNome5 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tEntradas = new javax.swing.JTable();
        bGerarRelatorio2 = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        lFuncionario1 = new javax.swing.JLabel();
        bTelaInicial1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(69, 95, 68));

        jLabel1.setFont(new java.awt.Font("Corbel Light", 0, 52)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(184, 236, 135));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/logo.png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(217, 217, 217));

        tVendas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cupom Fiscal", "Valor total", "Forma de Pagamento", "Data"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tVendas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tVendasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tVendas);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(69, 95, 68));
        jLabel4.setText("RELATÓRIO DE VENDAS");

        bBuscar1.setBackground(new java.awt.Color(69, 95, 68));
        bBuscar1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bBuscar1.setForeground(new java.awt.Color(255, 255, 255));
        bBuscar1.setText("Buscar");
        bBuscar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBuscar1ActionPerformed(evt);
            }
        });

        jPanel4.setLayout(new java.awt.GridLayout(1, 0, 0, 25));

        bGerarRelatorio1.setBackground(new java.awt.Color(69, 95, 68));
        bGerarRelatorio1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bGerarRelatorio1.setForeground(new java.awt.Color(255, 255, 255));
        bGerarRelatorio1.setText("Gerar Relatório");
        bGerarRelatorio1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bGerarRelatorio1ActionPerformed(evt);
            }
        });
        jPanel4.add(bGerarRelatorio1);

        labNome.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labNome.setText("Início:");

        labNome1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labNome1.setText("Fim:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(234, 234, 234)
                .addComponent(labNome)
                .addGap(18, 18, 18)
                .addComponent(dcInicio1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(labNome1)
                .addGap(18, 18, 18)
                .addComponent(dcFim1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(bBuscar1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(395, 395, 395)
                .addComponent(jLabel4)
                .addContainerGap(395, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 780, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(186, 186, 186))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bBuscar1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labNome, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(dcFim1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dcInicio1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(labNome1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(30, 30, 30)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );

        jPanel6.setBackground(new java.awt.Color(154, 198, 109));

        lFuncionario.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lFuncionario.setForeground(new java.awt.Color(69, 95, 68));
        lFuncionario.setText("Gerente ");

        bTelaInicial.setBackground(new java.awt.Color(102, 102, 102));
        bTelaInicial.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bTelaInicial.setForeground(new java.awt.Color(255, 255, 255));
        bTelaInicial.setText("Tela inicial");
        bTelaInicial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTelaInicialActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(bTelaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lFuncionario)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lFuncionario)
                    .addComponent(bTelaInicial, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout tab1Layout = new javax.swing.GroupLayout(tab1);
        tab1.setLayout(tab1Layout);
        tab1Layout.setHorizontalGroup(
            tab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tab1Layout.createSequentialGroup()
                .addGroup(tab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        tab1Layout.setVerticalGroup(
            tab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tab1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Relatório de Vendas", tab1);

        jPanel8.setBackground(new java.awt.Color(217, 217, 217));

        tSaidas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Valor", "Descrição", "Data"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tSaidas.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(tSaidas);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(69, 95, 68));
        jLabel5.setText("FLUXO DE CAIXA");

        labNome2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labNome2.setText("Início:");

        labNome3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labNome3.setText("Fim:");

        bBuscar2.setBackground(new java.awt.Color(69, 95, 68));
        bBuscar2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bBuscar2.setForeground(new java.awt.Color(255, 255, 255));
        bBuscar2.setText("Buscar");
        bBuscar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBuscar2ActionPerformed(evt);
            }
        });

        labNome4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labNome4.setText("Entradas:");

        labNome5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labNome5.setText("Saídas:");

        tEntradas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Valor", "Pagamento", "Data"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tEntradas.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(tEntradas);

        bGerarRelatorio2.setBackground(new java.awt.Color(69, 95, 68));
        bGerarRelatorio2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bGerarRelatorio2.setForeground(new java.awt.Color(255, 255, 255));
        bGerarRelatorio2.setText("Gerar Relatório");
        bGerarRelatorio2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bGerarRelatorio2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(447, 447, 447))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labNome5)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16))))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labNome4)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(427, 427, 427)
                        .addComponent(bGerarRelatorio2, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(241, 241, 241)
                .addComponent(labNome2)
                .addGap(18, 18, 18)
                .addComponent(dcInicio2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(labNome3)
                .addGap(18, 18, 18)
                .addComponent(dcFim2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(bBuscar2, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 242, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bBuscar2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labNome2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(dcFim2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dcInicio2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(labNome3, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(26, 26, 26)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labNome5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(labNome4))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addComponent(bGerarRelatorio2, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        jPanel11.setBackground(new java.awt.Color(154, 198, 109));

        lFuncionario1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lFuncionario1.setForeground(new java.awt.Color(69, 95, 68));
        lFuncionario1.setText("Gerente ");

        bTelaInicial1.setBackground(new java.awt.Color(102, 102, 102));
        bTelaInicial1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bTelaInicial1.setForeground(new java.awt.Color(255, 255, 255));
        bTelaInicial1.setText("Tela inicial");
        bTelaInicial1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTelaInicial1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(bTelaInicial1, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lFuncionario1)
                .addGap(19, 19, 19))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lFuncionario1)
                    .addComponent(bTelaInicial1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Fluxo de Caixa", jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bBuscar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBuscar1ActionPerformed
        try {
            //validar se a data de fim é maior que a data de início
            Date d1 = dcInicio1.getCalendar().getTime();
            Date d2 = dcFim1.getCalendar().getTime();
            if (d2.before(d1)) { //se data2 vem antes da data1
                util.exibirMensagemWarning("A data de fim precisa vir depois da data de início.");
            } else {
                atualizaTabelaVendas();
            }
        } catch (NullPointerException ex) {
            util.exibirMensagemWarning("Preencha as duas datas, por favor!");
        }
    }//GEN-LAST:event_bBuscar1ActionPerformed

    private void bGerarRelatorio1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bGerarRelatorio1ActionPerformed
        if (vendas.isEmpty()) {
            util.exibirMensagemWarning("Não é possível gerar relatório porque a pesqusia não obteve resultados no período desejado. Tente outro período.");
        } else {
            String arquivoRelatorio = "relatorio-vendas.jrxml"; //nome do relatório jasper
            try {
                //carrega o arquivo com o layout do relatorio
                JasperDesign jasperDesign = JRXmlLoader.load(getClass().getResourceAsStream("/br/edu/ifsp/pep/relatorio/" + arquivoRelatorio));

                //compila o relatório
                JasperReport relatorioCompilado = JasperCompileManager.compileReport(jasperDesign);

                //gera um data source a partir da lista de vendas
                JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(vendas);
                System.out.println(vendas);

                //preenche o relatório com os dados das vendas
                JasperPrint jasperPrint = JasperFillManager.fillReport(relatorioCompilado, null, dataSource);

                //exibe o relatório
                JasperViewer viewer = new JasperViewer(jasperPrint, true);
                viewer.setVisible(true);

            } catch (JRException ex) {
                ex.printStackTrace();
            }

        }
    }//GEN-LAST:event_bGerarRelatorio1ActionPerformed

    private void bTelaInicialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTelaInicialActionPerformed
        dispose();
    }//GEN-LAST:event_bTelaInicialActionPerformed

    private void bBuscar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBuscar2ActionPerformed
        try {
            //validar se a data de fim vem antes da data de início
            Date d1 = dcInicio2.getCalendar().getTime();
            Date d2 = dcFim2.getCalendar().getTime();
            if (d2.before(d1)) { //se data2 vem antes da data1
                util.exibirMensagemWarning("A data de fim precisa vir depois da data de início.");
            } else {
                atualizaTabelaEntradas();
                atualizaTabelaSaidas();
                if (entradas.isEmpty() && saidas.isEmpty()) {
                    util.exibirMensagem("Busca não retornou nenhum resultado. Tente outro período.");
                }
            }
        } catch (NullPointerException ex) {
            util.exibirMensagemWarning("Preencha as duas datas, por favor!");
        }
    }//GEN-LAST:event_bBuscar2ActionPerformed

    private void bGerarRelatorio2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bGerarRelatorio2ActionPerformed
        if (entradas.isEmpty() && saidas.isEmpty()) {
            util.exibirMensagemWarning("Não é possível gerar relatório porque a pesqusia não obteve resultados no período desejado. Tente outro período.");
        } else {
            //gerar relatório
        }
    }//GEN-LAST:event_bGerarRelatorio2ActionPerformed

    private void bTelaInicial1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTelaInicial1ActionPerformed
        dispose();
    }//GEN-LAST:event_bTelaInicial1ActionPerformed

    private void tVendasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tVendasMouseClicked
//        if(evt.getClickCount() == 2){
//            int linha = tVendas.getSelectedRow();
//            VerProdutosVendaView tela = new VerProdutosVendaView(null, true);
//            tela.setVenda(vendas.get(linha));
//            tela.setVisible(true);
//        }
    }//GEN-LAST:event_tVendasMouseClicked

    private void atualizaTabelaVendas() {
        DefaultTableModel modelo = (DefaultTableModel) tVendas.getModel();
        modelo.setNumRows(0);
        vendas.clear();
        vendas.addAll(vendaDAO.buscarPorPeriodo(dcInicio1.getDate(), dcFim1.getDate()));
        if (vendas.isEmpty()) {
            util.exibirMensagem("Busca não retornou nenhum resultado. Tente outro período.");
        } else {
            for (Venda v : vendas) {
                modelo.addRow(new Object[]{v.getCupomFiscal(), v.getValorTotal(), v.getFormaPagamento(), util.formatarDataBR(v.getDataVenda())});
            }
        }
    }

    private void atualizaTabelaEntradas() {
        //não dá pra usar o mesmo método que atualizaTabelaVendas porque o modelo das tabelas são diferentes
        DefaultTableModel modelo = (DefaultTableModel) tEntradas.getModel();
        modelo.setNumRows(0);
        entradas.clear();
        entradas.addAll(vendaDAO.buscarPorPeriodo(dcInicio2.getDate(), dcFim2.getDate()));
        for (Venda v : entradas) {
            modelo.addRow(new Object[]{v.getValorTotal(), v.getFormaPagamento(), util.formatarDataBR(v.getDataVenda())});
        }
    }

    private void atualizaTabelaSaidas() {
        DefaultTableModel modelo = (DefaultTableModel) tSaidas.getModel();
        modelo.setNumRows(0);
        saidas.clear();
        saidas.addAll(despesaDAO.buscarPorPeriodo(dcInicio2.getDate(), dcFim2.getDate()));
        for (Despesa s : saidas) {
            modelo.addRow(new Object[]{s.getValor(), s.getTipoDespesa().getDescricao(), util.formatarDataBR(s.getDataLancamento())});
        }
    }

//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(RelatorioView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(RelatorioView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(RelatorioView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(RelatorioView1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new RelatorioView1().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bBuscar1;
    private javax.swing.JButton bBuscar2;
    private javax.swing.JButton bGerarRelatorio1;
    private javax.swing.JButton bGerarRelatorio2;
    private javax.swing.JButton bTelaInicial;
    private javax.swing.JButton bTelaInicial1;
    private com.toedter.calendar.JDateChooser dcFim1;
    private com.toedter.calendar.JDateChooser dcFim2;
    private com.toedter.calendar.JDateChooser dcInicio1;
    private com.toedter.calendar.JDateChooser dcInicio2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lFuncionario;
    private javax.swing.JLabel lFuncionario1;
    private javax.swing.JLabel labNome;
    private javax.swing.JLabel labNome1;
    private javax.swing.JLabel labNome2;
    private javax.swing.JLabel labNome3;
    private javax.swing.JLabel labNome4;
    private javax.swing.JLabel labNome5;
    private javax.swing.JTable tEntradas;
    private javax.swing.JTable tSaidas;
    private javax.swing.JTable tVendas;
    private javax.swing.JPanel tab1;
    // End of variables declaration//GEN-END:variables
}
