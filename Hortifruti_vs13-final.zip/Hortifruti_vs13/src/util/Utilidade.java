package util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

public class Utilidade {
    private final SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
    private final DecimalFormat decFormat = new DecimalFormat("'R$ ' 0.##");
    
    public void exibirMensagem(String mensagem) {
        JOptionPane.showMessageDialog(null, mensagem);
    }

    public void exibirMensagemWarning(String mensagem) {
        JOptionPane.showMessageDialog(null, mensagem, "Atenção!", JOptionPane.WARNING_MESSAGE);
    }

    public void exibirMensagemError(String mensagem) {
        JOptionPane.showMessageDialog(null, mensagem, "Erro!", JOptionPane.ERROR_MESSAGE);
    }
    
    public int exibirMensagemConfirmacaoCancelar(){
        int opcao = JOptionPane.showConfirmDialog(null, "Você deseja mesmo cancelar?", "Confirmação", 0, 0);
        return opcao;
    }
    
    public int exibirMensagemConfirmacaoExcluir(){
        int opcao = JOptionPane.showConfirmDialog(null, "Você deseja mesmo excluir?", "Confirmação", 0, 0);
        return opcao;
    }
    
    public int exibirMensagemConfirmacaoLogout(){
        int opcao = JOptionPane.showConfirmDialog(null, "Você deseja mesmo desconectar?", "Confirmação", 0, 0);
        return opcao;
    }

    public String formatarDataBR(Date data) {
        return format.format(data);
    }
    
    public String formatarValor(BigDecimal valor){
        return decFormat.format(valor);
    }
}
